# BH POS STUDIO — by BH GRAPHICS  (Web / PWA · Phase 1)
Manage Smart. Sell Better.

## 1. Supabase
1. Create a project at supabase.com.
2. SQL Editor → paste all of `supabase/schema.sql` → Run.
3. Authentication → Providers → Email: keep enabled. For easy testing, turn **off** "Confirm email".
4. Project Settings → API: copy the **Project URL** and **anon public key**.

## 2. Run locally
```
npm install
cp .env.example .env     # paste the URL and anon key
npm run dev
```
Open http://localhost:5173 → **Create account**. The FIRST account becomes the active Admin.
Later sign-ups wait for approval: Admin → Settings → Users.

## 3. Deploy
**Vercel:** push to GitHub → vercel.com → Add New Project → import → add env vars
`VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` → Deploy. (`vercel.json` is included.)
**Netlify:** same idea; build `npm run build`, publish `dist` (`netlify.toml` is included).
Then in Supabase → Authentication → URL Configuration, set Site URL to your deployed address.

## 4. Install as an app
Chrome (Android): ⋮ → Install app / Add to Home screen. Chrome (Windows): install icon in the address bar.

## 5. Test offline
Sign in once while online, DevTools → Network → Offline (or airplane mode), reload: the app still opens.
Change the business name offline → "1 pending" shows → go online → it syncs automatically.

## Phase 2 — Products & POS billing
- Products (admin/manager): add/edit/delete, categories, barcode (scan with camera or generate), purchase/selling price, stock, low-stock level, CSV import/export.
- POS (everyone): search, tap or scan to add, quantities, discount (LKR or %), tax from Settings, Cash/Card/Bank/Credit, part-payment, customer select/add, invoice with Print (58/80 mm), PDF and WhatsApp.
- Settings → "Business & receipts": name, address, phone, tax %, footer, paper width.
- Offline: sales, stock movements, products and customers save locally first and upload in order when online. Stock and customer credit are calculated by the database from uploaded movements/sales, so two devices can't overwrite each other.
- Barcode: camera scanning works in Chrome on Android. On Windows use a USB/Bluetooth scanner — focus the POS search box and scan.
- Re-run nothing in Supabase: `schema.sql` from Phase 1 already includes everything. After updating the code run `npm install` (adds jspdf).

## Phase 3 — Customers, Inventory, Purchases, Expenses, Reports
**Existing Supabase project?** Run `supabase/phase3.sql` once (adds `deleted_at` to expenses). New projects: `schema.sql` already includes it.
- **Customers:** profiles, purchase + payment history, outstanding balances, "Receive payment", WhatsApp reminder.
- **Inventory:** stock in / stock out / stock count (adjustment), low/out filters, valuation, movement history, CSV.
- **Purchases:** suppliers, multi-line purchases that add stock and (optionally) update purchase prices.
- **Expenses:** by month and category, with CSV export.
- **Reports:** Sales, Profit & Loss, Product performance, Inventory valuation, Customer credit — each with CSV and PDF.
  Profit = sales (after discount, before tax) − cost of goods sold − expenses. Purchases are stock, not expenses.
- **Dashboard:** today's sales/profit, revenue, expenses, products, low stock, customers, recent sales, weekly/monthly chart.
- **Multi-device:** sales, purchases, payments and stock movements from other devices download automatically. Settings → "Re-download all data" forces a full refresh.

## Phase 4 — Bluetooth printing, backup/restore, returns & voids
**Existing Supabase project?** Run `supabase/phase4.sql` once (adds the returns tables). New projects: `schema.sql` already has it.
- **Bluetooth thermal printing:** Settings → Receipt printer → Connect (Chrome on Android/Windows, HTTPS). 58 mm (32 chars) and 80 mm (48 chars) follow the paper width setting. "Bluetooth" button on every invoice. Works with BLE (Bluetooth 4+) ESC/POS printers; classic-Bluetooth-only printers are invisible to browsers. Text mode prints English letters/numbers (other characters show as `?`); use the Print button for Sinhala/Tamil names.
- **Backup / restore:** Settings → Backup & restore. One JSON file with everything on the device. Restore (admin) replaces local data; tick the re-upload box only to refill a new, empty Supabase database.
- **Returns & voids (admin/manager):** open any invoice (POS → Recent sales) → Return / void. Partial or full returns, restock or not, credit owed on the sale is cancelled first, the rest is refunded. Reports, dashboard and profit are NET of returns, counted on the day of the return.

## Phase 5 — Supplier payments, product photos, returns report, go-live
**Existing Supabase project?** Run `supabase/phase5.sql` once (supplier payments table).
- **Supplier payments:** Purchases → Suppliers → Pay. "Owed" = unpaid purchases − payments made.
- **Product photos:** Products → add/edit → Choose photo (shrunk to a small JPEG and stored with the product, so it works offline). Shown in the product list and POS tiles.
- **Returns report:** Reports → Returns.
- Fixed: a TypeScript typing error in the sync queue found by an offline type-check.

### Go-live checklist
1. Supabase: run `schema.sql` (new project) or the `phase3/4/5.sql` files in order (existing project).
2. Supabase → Authentication → Providers → Email: decide whether "Confirm email" stays on.
3. Push the folder to GitHub → Vercel/Netlify → add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` → Deploy.
4. Supabase → Authentication → URL Configuration: set Site URL to your live address.
5. Open the live URL, **Create account** — the first account becomes the Admin. Then Settings → set business name, address, tax, paper width.
6. Install: Chrome → ⋮ → Install app. Pair the printer in Settings (HTTPS required for Bluetooth and camera).
7. Make a test sale offline (DevTools → Network → Offline), go online, confirm it syncs and stock in Supabase drops.
8. Download a backup (Settings) and repeat weekly.

### Troubleshooting
- Pending badge never clears: check the browser console and the `outbox` rows' `lastError` (DevTools → Application → IndexedDB → bh_pos_studio → outbox). A missing SQL migration is the usual cause.
- Camera/Bluetooth buttons missing: open the site over HTTPS in Chrome.
- Blank page after deploy: environment variables missing (the app then shows a "Connect Supabase" screen).

## Phase 6 — Sinhala/Tamil receipts, backup reminder, sync status
- **Image print mode:** Settings → Receipt printer → Print mode → *Image*. The receipt is drawn like a picture, so Sinhala, Tamil and English all print correctly (uses your phone's fonts). Slower than Text mode (about 5–15 s per receipt) — keep *Text* for English-only shops. "Test print" shows all three languages.
- **Backup reminder:** the Dashboard asks staff to download a backup when none was made in 7 days.
- **Sync status:** Settings → Sync status shows how many changes are waiting and any the database rejected, with the reason, plus a *Sync now* button.
