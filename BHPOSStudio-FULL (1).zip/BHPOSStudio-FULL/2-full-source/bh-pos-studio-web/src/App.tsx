import { useEffect, useState } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './lib/auth'
import { isConfigured } from './lib/supabase'
import { startSync } from './lib/sync'
import { MODULES } from './lib/modules'
import { Splash } from './components/Brand'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Settings from './pages/Settings'
import ModulePage from './pages/ModulePage'
import POS from './pages/POS'
import Products from './pages/Products'
import Customers from './pages/Customers'
import Inventory from './pages/Inventory'
import Purchases from './pages/Purchases'
import Expenses from './pages/Expenses'
import Reports from './pages/Reports'
import { Pending, Setup } from './pages/Notices'

const LIVE: Record<string, JSX.Element> = { dashboard: <Dashboard />, settings: <Settings />, pos: <POS />, products: <Products />, customers: <Customers />, inventory: <Inventory />, purchases: <Purchases />, expenses: <Expenses />, reports: <Reports /> }

export default function App() {
  const { profile, loading } = useAuth()
  const [boot, setBoot] = useState(true)
  useEffect(() => { const t = setTimeout(() => setBoot(false), 1400); return () => clearTimeout(t) }, [])
  const active = Boolean(profile?.active)
  useEffect(() => (active ? startSync() : undefined), [active])

  if (!isConfigured) return <Setup />
  if (boot || loading) return <Splash />
  if (!profile) return <Login />
  if (!profile.active) return <Pending />

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        {MODULES.filter(m => m.roles.includes(profile.role)).map(m => (
          <Route key={m.path} path={m.path}
            element={LIVE[m.path] ?? <ModulePage m={m} />} />
        ))}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  )
}
