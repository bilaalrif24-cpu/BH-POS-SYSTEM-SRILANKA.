import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../lib/db'
import { exportBackup } from '../lib/backup'

/** Nudges staff to download a backup if none was made in the last 7 days (only once there is data worth saving). */
export default function BackupReminder() {
  const [last, setLast] = useState(localStorage.getItem('bh-last-backup'))
  const hasData = useLiveQuery(async () => (await db.sales.count()) + (await db.products.count()) > 0, [])
  const days = last ? (Date.now() - Date.parse(last)) / 864e5 : Infinity
  if (!hasData || days < 7) return null
  return (
    <div className="glass flex flex-wrap items-center justify-between gap-3 border-amber-500/40 p-4">
      <div className="text-sm"><div className="font-semibold">Back up your data</div>
        <div className="text-slate-500 dark:text-slate-400">{last ? `Last backup was ${Math.floor(days)} days ago.` : 'You have not made a backup yet.'}</div></div>
      <button className="btn-primary" onClick={async () => { await exportBackup(); setLast(localStorage.getItem('bh-last-backup')) }}>Download backup</button>
    </div>
  )
}
