import { fmt } from '../lib/money'

export default function BarChart({ data }: { data: { label: string; a: number; b: number }[] }) {
  const max = Math.max(1, ...data.map(d => Math.max(d.a, d.b)))
  return (
    <div>
      <div className="flex h-44 items-end gap-1">
        {data.map((d, i) => (
          <div key={i} className="flex h-full flex-1 items-end justify-center gap-px" title={`Day ${d.label}: sales ${fmt(d.a)} · profit ${fmt(d.b)}`}>
            <div className="w-full max-w-[14px] rounded-t bg-royal" style={{ height: `${(d.a / max) * 100}%` }} />
            <div className="w-full max-w-[14px] rounded-t bg-emerald-500" style={{ height: `${(Math.max(d.b, 0) / max) * 100}%` }} />
          </div>
        ))}
      </div>
      <div className="mt-1 flex gap-1 text-[10px] text-slate-500 dark:text-slate-400">
        {data.map((d, i) => <div key={i} className="flex-1 text-center">{data.length > 10 && i % 3 ? '' : d.label}</div>)}
      </div>
      <div className="mt-2 flex gap-4 text-xs"><span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-royal" />Net sales</span><span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-emerald-500" />Gross profit</span></div>
    </div>
  )
}
