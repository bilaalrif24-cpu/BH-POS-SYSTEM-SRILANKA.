import { useEffect, useRef, useState } from 'react'
import Modal from './Modal'

/** Camera scanning uses the browser's BarcodeDetector (Chrome on Android). Elsewhere, keyboard-style
 *  USB/Bluetooth scanners work by typing into the search box and pressing Enter. */
export default function BarcodeScanner({ onDetect, onClose }: { onDetect: (code: string) => void; onClose: () => void }) {
  const video = useRef<HTMLVideoElement>(null)
  const cb = useRef(onDetect)
  cb.current = onDetect
  const [err, setErr] = useState('')

  useEffect(() => {
    if (!('BarcodeDetector' in window)) { setErr('Camera scanning is not supported in this browser. Use a USB/Bluetooth scanner (it types the code) or enter it manually.'); return }
    if (!navigator.mediaDevices?.getUserMedia) { setErr('Camera is unavailable (the site must be opened over HTTPS).'); return }
    let stop = false, raf = 0, stream: MediaStream | undefined, last = '', lastAt = 0
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const det = new (window as any).BarcodeDetector({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code'] })
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }).then(async s => {
      stream = s
      const v = video.current!
      v.srcObject = s
      await v.play()
      const tick = async () => {
        if (stop) return
        try {
          const codes = await det.detect(v)
          const now = Date.now()
          if (codes.length && (codes[0].rawValue !== last || now - lastAt > 2000)) { last = codes[0].rawValue; lastAt = now; cb.current(last) }
        } catch { /* ignore frame errors */ }
        raf = requestAnimationFrame(tick)
      }
      tick()
    }).catch(() => setErr('Camera permission was denied or no camera was found.'))
    return () => { stop = true; cancelAnimationFrame(raf); stream?.getTracks().forEach(t => t.stop()) }
  }, [])

  return (
    <Modal title="Scan barcode" onClose={onClose}>
      {err ? <p className="text-sm text-red-500">{err}</p> : <video ref={video} className="w-full rounded-xl bg-black" playsInline muted />}
      <button className="btn-ghost mt-3 w-full" onClick={onClose}>Close</button>
    </Modal>
  )
}
