import Logo from './Logo'

export function BrandHeader({ size = 80 }: { size?: number }) {
  return (
    <div className="flex flex-col items-center text-center">
      <Logo size={size} />
      <h1 className="mt-4 text-2xl font-extrabold tracking-wider">BH POS STUDIO</h1>
      <p className="text-sm font-semibold tracking-[0.3em] text-slate-500 dark:text-silver">BY BH GRAPHICS</p>
      <p className="mt-1 text-[11px] tracking-[0.25em] text-slate-500 dark:text-slate-400">MANAGE SMART. SELL BETTER.</p>
    </div>
  )
}

export function Spinner({ className = 'h-6 w-6' }: { className?: string }) {
  return <div className={`${className} animate-spin rounded-full border-2 border-royal/30 border-t-royal`} />
}

export function Splash() {
  return (
    <div className="app-bg flex min-h-full flex-col items-center justify-center gap-8">
      <div className="animate-pulse"><BrandHeader size={112} /></div>
      <Spinner />
    </div>
  )
}
