export type Cell = string | number
const n2 = (n: number) => n.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export default function DataTable({ head, rows }: { head: string[]; rows: Cell[][] }) {
  if (!rows.length) return <p className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">Nothing to show for this selection.</p>
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[480px] text-sm">
        <thead><tr className="border-b border-slate-300/60 text-left text-xs text-slate-500 dark:border-white/10 dark:text-slate-400">
          {head.map((h, i) => <th key={i} className={`py-2 pr-3 font-semibold ${i ? 'text-right' : ''}`}>{h}</th>)}
        </tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-slate-200/60 dark:border-white/5">
              {r.map((c, j) => <td key={j} className={`py-2 pr-3 ${j ? 'text-right tabular-nums' : ''}`}>{typeof c === 'number' ? n2(c) : c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
