import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Bluetooth, FileDown, MessageCircle, Printer, Undo2 } from 'lucide-react'
import { db, type Sale, type SaleItem } from '../lib/db'
import { useAuth } from '../lib/auth'
import { useBiz } from '../lib/hooks'
import { downloadPdf, printReceipt, whatsappUrl, type Buyer } from '../lib/invoice'
import { receiptBytes } from '../lib/printjob'
import { btSupported, sendToPrinter } from '../lib/bluetooth'
import { fmt } from '../lib/money'
import Modal from './Modal'
import ReturnModal from './ReturnModal'

export default function InvoiceModal({ sale, items, buyer, onClose }: { sale: Sale; items: SaleItem[]; buyer: Buyer | null; onClose: () => void }) {
  const { profile } = useAuth()
  const biz = useBiz()
  const returns = useLiveQuery(() => db.saleReturns.where('sale_id').equals(sale.id).toArray(), [sale.id]) ?? []
  const [ret, setRet] = useState(false)
  const [btMsg, setBtMsg] = useState('')
  const returned = returns.reduce((s, r) => s + Number(r.total), 0)
  const canReturn = profile?.role !== 'cashier'

  async function btPrint() {
    setBtMsg('Printing…')
    try { await sendToPrinter(receiptBytes(sale, items, biz, buyer)); setBtMsg('Sent to printer.') }
    catch (e) { setBtMsg(e instanceof Error ? e.message : 'Could not print.') }
  }

  return (
    <Modal title={`Invoice ${sale.invoice_no}`} onClose={onClose}>
      <div className="space-y-1 rounded-xl bg-slate-100 p-3 font-mono text-xs dark:bg-white/5">
        <div className="text-center font-bold">{biz.name}</div>
        <div className="text-center">{new Date(sale.created_at).toLocaleString('en-LK')}{buyer ? ` · ${buyer.name}` : ''}</div>
        <hr className="my-2 border-dashed border-slate-400" />
        {items.map(i => <div key={i.id} className="flex justify-between gap-2"><span>{i.name} × {i.qty}</span><span>{fmt(i.line_total)}</span></div>)}
        <hr className="my-2 border-dashed border-slate-400" />
        {sale.discount > 0 && <div className="flex justify-between"><span>Discount</span><span>-{fmt(sale.discount)}</span></div>}
        {sale.tax > 0 && <div className="flex justify-between"><span>Tax</span><span>{fmt(sale.tax)}</span></div>}
        <div className="flex justify-between text-sm font-bold"><span>TOTAL</span><span>{fmt(sale.total)}</span></div>
        <div className="flex justify-between"><span>Paid</span><span>{fmt(sale.paid)}</span></div>
        {sale.balance > 0 && <div className="flex justify-between font-bold text-amber-600"><span>Balance due</span><span>{fmt(sale.balance)}</span></div>}
        {returned > 0 && <div className="flex justify-between font-bold text-red-500"><span>Returned</span><span>-{fmt(returned)}</span></div>}
      </div>
      <div className={`mt-4 grid gap-2 ${btSupported() ? 'grid-cols-2' : 'grid-cols-3'}`}>
        <button className="btn-primary !px-2" onClick={() => printReceipt(sale, items, biz, buyer)}><Printer size={16} />Print</button>
        {btSupported() && <button className="btn-ghost !px-2" onClick={() => void btPrint()}><Bluetooth size={16} />Bluetooth</button>}
        <button className="btn-ghost !px-2" onClick={() => void downloadPdf(sale, items, biz, buyer)}><FileDown size={16} />PDF</button>
        <a className="btn-ghost !px-2" href={whatsappUrl(sale, items, biz, buyer)} target="_blank" rel="noreferrer"><MessageCircle size={16} />WhatsApp</a>
      </div>
      {btMsg && <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">{btMsg}</p>}
      {canReturn && <button className="btn-ghost mt-2 w-full" onClick={() => setRet(true)}><Undo2 size={16} />Return / void</button>}
      <button className="btn-ghost mt-2 w-full" onClick={onClose}>Done</button>
      {ret && <ReturnModal sale={sale} items={items} onClose={() => setRet(false)} />}
    </Modal>
  )
}
