import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { LogOut, Menu, Monitor, Moon, Sun, X } from 'lucide-react'
import { useAuth } from '../lib/auth'
import { MODULES } from '../lib/modules'
import { useSetting } from '../lib/hooks'
import { useTheme, type ThemeMode } from '../lib/theme'
import Logo from './Logo'
import SyncBadge from './SyncBadge'

const NEXT: Record<ThemeMode, ThemeMode> = { system: 'light', light: 'dark', dark: 'system' }

export default function Layout() {
  const { profile, signOut } = useAuth()
  const { mode, setMode } = useTheme()
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  const business = useSetting('business_name', 'My Business')
  useEffect(() => setOpen(false), [loc.pathname])

  const mods = MODULES.filter(m => profile && m.roles.includes(profile.role))
  const current = mods.find(m => loc.pathname.startsWith('/' + m.path))
  const ThemeIcon = mode === 'system' ? Monitor : mode === 'light' ? Sun : Moon

  const nav = (
    <div className="flex h-full flex-col p-4">
      <div className="flex items-center gap-3 px-2 pb-5">
        <Logo size={44} />
        <div>
          <div className="font-extrabold tracking-wide">BH POS STUDIO</div>
          <div className="text-[10px] font-semibold tracking-[0.25em] text-slate-500 dark:text-silver">BY BH GRAPHICS</div>
        </div>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto">
        {mods.map(m => (
          <NavLink key={m.path} to={'/' + m.path}
            className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${isActive ? 'bg-royal text-white shadow-lg shadow-royal/30' : 'hover:bg-slate-200/70 dark:hover:bg-white/10'}`}>
            <m.icon size={18} />{m.title}
          </NavLink>
        ))}
      </nav>
      <div className="mt-3 rounded-xl bg-slate-200/60 p-3 dark:bg-white/5">
        <div className="truncate text-sm font-semibold">{profile?.fullName}</div>
        <div className="text-xs capitalize text-slate-500 dark:text-slate-400">{profile?.role} · {business}</div>
        <button onClick={() => void signOut()} className="btn-ghost mt-2 w-full !py-1.5 text-xs"><LogOut size={14} />Sign out</button>
      </div>
    </div>
  )

  return (
    <div className="app-bg">
      <aside className="glass fixed inset-y-0 left-0 z-30 hidden w-64 !rounded-none border-y-0 border-l-0 lg:block">{nav}</aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white dark:bg-navy">
            <button className="absolute right-3 top-3 p-2" onClick={() => setOpen(false)} aria-label="Close menu"><X size={20} /></button>
            {nav}
          </aside>
        </div>
      )}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-white/40 bg-white/60 px-4 py-3 backdrop-blur-xl dark:border-white/10 dark:bg-ink/60"
          style={{ paddingTop: 'max(0.75rem, env(safe-area-inset-top))' }}>
          <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={22} /></button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-lg font-bold">{current?.title ?? 'BH POS STUDIO'}</div>
            <div className="truncate text-xs text-slate-500 dark:text-slate-400">{business}</div>
          </div>
          <SyncBadge />
          <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10" onClick={() => setMode(NEXT[mode])} aria-label={`Theme: ${mode}`}><ThemeIcon size={20} /></button>
        </header>
        <main className="mx-auto max-w-6xl p-4 sm:p-6"><Outlet /></main>
      </div>
    </div>
  )
}
