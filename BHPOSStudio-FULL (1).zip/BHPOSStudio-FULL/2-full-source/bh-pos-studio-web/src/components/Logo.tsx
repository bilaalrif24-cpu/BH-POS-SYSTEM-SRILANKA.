import { useId } from 'react'

export default function Logo({ size = 48 }: { size?: number }) {
  const id = useId().replace(/:/g, '')
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="BH GRAPHICS monogram">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3B6BFF" /><stop offset="1" stopColor="#1B3FB8" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="47" fill={`url(#${id})`} stroke="#C9D1DC" strokeWidth="3" />
      <text x="50" y="62" textAnchor="middle" fontSize="38" fontWeight="800" fill="#C9D1DC" fontFamily="system-ui,sans-serif">BH</text>
    </svg>
  )
}
