import type { ReactNode } from 'react'
import { X } from 'lucide-react'

export default function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center sm:p-4" onClick={onClose}>
      <div className={`glass max-h-[92vh] w-full overflow-y-auto !rounded-b-none bg-white p-5 dark:bg-navy sm:!rounded-2xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'}`} onClick={e => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-bold">{title}</h3>
          <button onClick={onClose} aria-label="Close"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  )
}
