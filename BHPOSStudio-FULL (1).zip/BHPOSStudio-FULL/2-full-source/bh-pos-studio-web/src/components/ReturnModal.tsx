import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import type { Sale, SaleItem } from '../lib/db'
import { useAuth } from '../lib/auth'
import { computeReturn, createReturn, returnedQty } from '../lib/returns'
import { fmt } from '../lib/money'
import Modal from './Modal'

export default function ReturnModal({ sale, items, onClose }: { sale: Sale; items: SaleItem[]; onClose: () => void }) {
  const { profile } = useAuth()
  const done = useLiveQuery(() => returnedQty(sale.id), [sale.id])
  const [qtys, setQtys] = useState<Record<string, string>>({})
  const [method, setMethod] = useState('cash')
  const [reason, setReason] = useState('')
  const [restock, setRestock] = useState(true)
  const [err, setErr] = useState('')
  const [result, setResult] = useState('')
  if (!done) return null
  const left = (i: SaleItem) => Number(i.qty) - (done.map.get(i.id) ?? 0)
  const lines = items.map(item => ({ item, qty: Math.min(Number(qtys[item.id]) || 0, left(item)) })).filter(l => l.qty > 0)
  const c = computeReturn(sale, lines)
  const allGone = items.every(i => left(i) <= 0)

  async function submit() {
    if (!profile) return
    const r = await createReturn({ sale, items, qtys: Object.fromEntries(lines.map(l => [l.item.id, l.qty])), method, reason, restock, userId: profile.id })
    if (typeof r === 'string') { setErr(r); return }
    setResult(`Return saved. Total ${fmt(r.total)}${r.credit > 0 ? ` — ${fmt(r.credit)} taken off the customer's credit` : ''}${r.refunded > 0 ? ` — refund ${fmt(r.refunded)} via ${method}` : ''}.`)
  }

  if (result) return (
    <Modal title="Return complete" onClose={onClose}>
      <p className="text-sm">{result}</p>
      <button className="btn-primary mt-4 w-full" onClick={onClose}>Done</button>
    </Modal>
  )

  return (
    <Modal title={`Return / void — ${sale.invoice_no}`} onClose={onClose}>
      {allGone ? <p className="text-sm">Every item on this sale has already been returned.</p> : (
        <div className="space-y-3">
          <button className="text-xs text-royal hover:underline" onClick={() => setQtys(Object.fromEntries(items.map(i => [i.id, String(left(i))])))}>Void whole sale (return everything left)</button>
          {items.map(i => (
            <div key={i.id} className="flex items-center gap-2">
              <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{i.name}</div><div className="text-xs text-slate-500 dark:text-slate-400">{left(i)} of {i.qty} returnable @ {fmt(i.unit_price)}</div></div>
              <input className="input !w-20 !py-1.5 text-center" inputMode="decimal" placeholder="0" disabled={left(i) <= 0} value={qtys[i.id] ?? ''} onChange={e => setQtys({ ...qtys, [i.id]: e.target.value })} />
            </div>
          ))}
          <input className="input" placeholder="Reason (wrong item, damaged, customer changed mind…)" value={reason} onChange={e => setReason(e.target.value)} />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={restock} onChange={e => setRestock(e.target.checked)} />Put items back into stock (untick if damaged)</label>
          <label className="block text-xs">Refund paid by
            <select className="input mt-1" value={method} onChange={e => setMethod(e.target.value)}><option value="cash">Cash</option><option value="card">Card</option><option value="bank_transfer">Bank transfer</option></select></label>
          <div className="glass flex justify-between p-3 font-bold"><span>Return value</span><span>{fmt(c.total)}</span></div>
          {sale.balance > 0 && <p className="text-xs text-slate-500 dark:text-slate-400">This sale had {fmt(sale.balance)} on credit — that is cancelled first, only the rest is refunded.</p>}
          {err && <p className="text-sm text-red-500">{err}</p>}
          <div className="flex gap-2"><button className="btn-primary flex-1" disabled={!lines.length} onClick={() => void submit()}>Confirm return</button><button className="btn-ghost" onClick={onClose}>Cancel</button></div>
        </div>
      )}
    </Modal>
  )
}
