import { Wifi, WifiOff } from 'lucide-react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../lib/db'
import { useOnline } from '../lib/hooks'

export default function SyncBadge() {
  const online = useOnline()
  const pending = useLiveQuery(() => db.outbox.count(), []) ?? 0
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${online ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'}`}>
      {online ? <Wifi size={14} /> : <WifiOff size={14} />}
      {online ? 'Online' : 'Offline'}{pending > 0 && ` · ${pending} pending`}
    </span>
  )
}
