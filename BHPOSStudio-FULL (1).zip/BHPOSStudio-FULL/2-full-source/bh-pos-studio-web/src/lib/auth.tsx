import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { supabase } from './supabase'
import { db, type CachedProfile } from './db'

interface AuthCtx {
  profile: CachedProfile | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<string | null>
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null; info?: string }>
  signOut: () => Promise<void>
  refresh: () => Promise<void>
}
const Ctx = createContext<AuthCtx>(null as unknown as AuthCtx)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<CachedProfile | null>(null)
  const [loading, setLoading] = useState(true)

  // Online: read the latest role from Supabase and cache it. Offline: fall back to the cached copy.
  const loadProfile = useCallback(async (userId: string, email?: string) => {
    let p: CachedProfile | undefined
    if (supabase && navigator.onLine) {
      const { data } = await supabase.from('profiles').select('id,email,full_name,role,active').eq('id', userId).maybeSingle()
      if (data) {
        p = { id: data.id, email: data.email ?? email ?? '', fullName: data.full_name ?? '', role: data.role, active: data.active }
        await db.profile.put(p)
      }
    }
    if (!p) p = await db.profile.get(userId)
    setProfile(p ?? null)
  }, [])

  useEffect(() => {
    if (!supabase) { setLoading(false); return }
    let alive = true
    supabase.auth.getSession().then(async ({ data }) => {
      if (data.session) await loadProfile(data.session.user.id, data.session.user.email)
      if (alive) setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT') setProfile(null)
      else if (session && (event === 'SIGNED_IN' || event === 'USER_UPDATED')) {
        setTimeout(() => { void loadProfile(session.user.id, session.user.email) }, 0)
      }
    })
    return () => { alive = false; sub.subscription.unsubscribe() }
  }, [loadProfile])

  const signIn: AuthCtx['signIn'] = async (email, password) => {
    if (!supabase) return 'Supabase is not configured'
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    return error?.message ?? null
  }
  const signUp: AuthCtx['signUp'] = async (email, password, fullName) => {
    if (!supabase) return { error: 'Supabase is not configured' }
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { full_name: fullName.trim() } } })
    if (error) return { error: error.message }
    return { error: null, info: data.session ? undefined : 'Account created. Check your email to confirm, then sign in.' }
  }
  const signOut = async () => {
    await db.profile.clear()
    await supabase?.auth.signOut()
    setProfile(null)
  }
  const refresh = async () => {
    const { data } = (await supabase?.auth.getSession()) ?? { data: { session: null } }
    if (data.session) await loadProfile(data.session.user.id, data.session.user.email)
  }

  return <Ctx.Provider value={{ profile, loading, signIn, signUp, signOut, refresh }}>{children}</Ctx.Provider>
}
