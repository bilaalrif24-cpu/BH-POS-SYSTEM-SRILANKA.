import { db } from './db'
import { customerPayload, productPayload } from './catalog'
import { enqueue, syncNow } from './sync'

const TABLES = ['categories', 'products', 'customers', 'suppliers', 'sales', 'saleItems', 'stockMovements', 'purchases', 'purchaseItems',
  'expenses', 'payments', 'saleReturns', 'saleReturnItems', 'supplierPayments', 'settings', 'outbox'] as const

export async function exportBackup() {
  const tables: Record<string, unknown[]> = {}
  for (const t of TABLES) tables[t] = await db.table(t).toArray()
  const blob = new Blob([JSON.stringify({ app: 'bh-pos-studio', version: 1, exportedAt: new Date().toISOString(), tables })], { type: 'application/json' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = `bh-pos-backup-${new Date().toISOString().slice(0, 10)}.json`
  a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 1000)
  localStorage.setItem('bh-last-backup', new Date().toISOString())
}

type R = Record<string, unknown>
async function enqueueAll() {
  const push = async (server: string, rows: R[]) => { for (let i = 0; i < rows.length; i += 200) await enqueue(server, rows.slice(i, i + 200)) }
  // Order respects foreign keys.
  await push('categories', await db.categories.toArray() as unknown as R[])
  await push('suppliers', await db.suppliers.toArray() as unknown as R[])
  await push('customers', (await db.customers.toArray()).map(customerPayload) as unknown as R[])
  await push('products', (await db.products.toArray()).map(productPayload) as unknown as R[])
  await push('settings', (await db.settings.toArray()).map(s => ({ key: s.key, value: s.value, updated_at: s.updatedAt })))
  await push('purchases', await db.purchases.toArray() as unknown as R[])
  await push('purchase_items', await db.purchaseItems.toArray() as unknown as R[])
  await push('supplier_payments', await db.supplierPayments.toArray() as unknown as R[])
  await push('sales', await db.sales.toArray() as unknown as R[])
  await push('sale_items', await db.saleItems.toArray() as unknown as R[])
  await push('sale_returns', await db.saleReturns.toArray() as unknown as R[])
  await push('sale_return_items', await db.saleReturnItems.toArray() as unknown as R[])
  await push('payments', await db.payments.toArray() as unknown as R[])
  await push('expenses', await db.expenses.toArray() as unknown as R[])
  await push('stock_movements', await db.stockMovements.toArray() as unknown as R[])
}

/** Replaces local data with the backup. With `reupload`, everything is queued to Supabase (use for a new/empty database). */
export async function restoreBackup(text: string, reupload: boolean) {
  let j: any
  try { j = JSON.parse(text) } catch { throw new Error('That file is not a valid backup (not JSON).') }
  if (j?.app !== 'bh-pos-studio' || typeof j.tables !== 'object') throw new Error('This is not a BH POS STUDIO backup file.')
  const present = TABLES.filter(t => t in j.tables)
  for (const t of present) if (!Array.isArray(j.tables[t])) throw new Error(`Backup is damaged (${t}).`)
  await db.transaction('rw', present.map(t => db.table(t)), async () => {
    for (const t of present) {
      const tb = db.table(t)
      await tb.clear()
      if (j.tables[t].length) await tb.bulkPut(j.tables[t])
    }
  })
  if (reupload) { await db.outbox.clear(); await enqueueAll() }
  void syncNow()
  return Object.fromEntries(present.filter(t => t !== 'outbox').map(t => [t, j.tables[t].length])) as Record<string, number>
}
