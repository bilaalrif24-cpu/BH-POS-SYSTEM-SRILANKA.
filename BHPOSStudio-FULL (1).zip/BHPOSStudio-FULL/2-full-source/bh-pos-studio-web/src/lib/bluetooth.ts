/* Web Bluetooth (Chrome on Android / Windows / ChromeOS, HTTPS only). Works with BLE ESC/POS thermal printers.
   Classic-Bluetooth-only printers are NOT visible to browsers. */
/* eslint-disable @typescript-eslint/no-explicit-any */
const SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb', '0000ffe0-0000-1000-8000-00805f9b34fb', '0000ff00-0000-1000-8000-00805f9b34fb',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455', 'e7810a71-73ae-499d-8c15-faa9aef0c3f2', '0000fee7-0000-1000-8000-00805f9b34fb',
  '0000ae30-0000-1000-8000-00805f9b34fb', '0000fff0-0000-1000-8000-00805f9b34fb'
]
let device: any = null
let channel: any = null

export const btSupported = () => 'bluetooth' in navigator
export const btName = (): string | null => device?.name ?? localStorage.getItem('bh-bt-name')
export const btConnected = () => Boolean(device?.gatt?.connected && channel)

async function openChannel(dev: any) {
  const server = await dev.gatt.connect()
  for (const s of await server.getPrimaryServices()) {
    for (const c of await s.getCharacteristics()) {
      if (c.properties.write || c.properties.writeWithoutResponse) { channel = c; return }
    }
  }
  throw new Error('Connected, but no writable printer channel was found. This printer may not be supported by the browser.')
}

/** Must be called from a click (browser rule). */
export async function connectPrinter() {
  try {
    device = await (navigator as any).bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: SERVICES })
    device.addEventListener('gattserverdisconnected', () => { channel = null })
    await openChannel(device)
    localStorage.setItem('bh-bt-name', device.name ?? 'Printer')
  } catch (e) {
    device = null; channel = null
    if ((e as Error).name === 'NotFoundError') throw new Error('No printer was selected.')
    throw e
  }
}

export function disconnectPrinter() { try { device?.gatt?.disconnect() } catch { /* ignore */ } channel = null }

export async function sendToPrinter(bytes: Uint8Array) {
  if (!btSupported()) throw new Error('Bluetooth printing is not supported in this browser.')
  if (!device) await connectPrinter()
  else if (!btConnected()) await openChannel(device)
  const write = async (size: number) => {
    for (let i = 0; i < bytes.length; i += size) {
      const chunk = bytes.slice(i, i + size)
      if (channel.properties.writeWithoutResponse) await channel.writeValueWithoutResponse(chunk); else await channel.writeValue(chunk)
      await new Promise(r => setTimeout(r, 25))
    }
  }
  try { await write(100) } catch { await write(20) } // small chunks for printers with the minimum BLE packet size
}
