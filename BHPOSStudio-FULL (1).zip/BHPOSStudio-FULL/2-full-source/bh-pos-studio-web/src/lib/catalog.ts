import { db, type Category, type Customer, type Product, type StockMovement } from './db'
import { enqueue, syncNow } from './sync'
import { round2, uuid } from './money'

// Stock and credit are derived on the server from movements/sales, so they are never uploaded directly.
export const productPayload = (p: Product) => { const { stock_qty, ...rest } = p; return rest }
export const customerPayload = (c: Customer) => { const { credit_balance, ...rest } = c; return rest }
const num = (s: string) => Number(s.replace(/,/g, '')) || 0

export async function createCategory(name: string): Promise<string> {
  const c: Category = { id: uuid(), name: name.trim(), created_at: new Date().toISOString() }
  await db.transaction('rw', db.categories, db.outbox, async () => { await db.categories.put(c); await enqueue('categories', c) })
  void syncNow()
  return c.id
}

export async function ensureCategory(name: string): Promise<string> {
  const n = name.trim().toLowerCase()
  const ex = await db.categories.filter(c => c.name.toLowerCase() === n).first()
  return ex ? ex.id : createCategory(name)
}

export interface ProductInput {
  id?: string; name: string; sku: string; barcode: string; categoryId: string | null
  image?: string | null; purchase: number; selling: number; low: number; openingStock?: number; adjust?: number; adjustReason?: string
}

export async function saveProduct(i: ProductInput): Promise<string | null> {
  const name = i.name.trim()
  if (!name) return 'Product name is required'
  if (i.purchase < 0 || i.selling < 0) return 'Prices cannot be negative'
  const barcode = i.barcode.trim() || null
  if (barcode) {
    const dup = await db.products.where('barcode').equals(barcode).first()
    if (dup && dup.id !== i.id) return `Barcode already used by "${dup.name}"`
  }
  const now = new Date().toISOString()
  const existing = i.id ? await db.products.get(i.id) : undefined
  if (i.id && !existing) return 'Product not found'
  const open = Math.max(0, i.openingStock ?? 0)
  const adj = i.adjust ?? 0
  const base = {
    name, sku: i.sku.trim() || null, barcode, category_id: i.categoryId,
    purchase_price: i.purchase, selling_price: i.selling, low_stock_level: i.low, updated_at: now, deleted_at: null
  }
  const product: Product = existing
    ? { ...existing, ...base, ...(i.image !== undefined ? { image_url: i.image } : {}), stock_qty: round2(Number(existing.stock_qty) + adj) }
    : { id: uuid(), ...base, stock_qty: open, image_url: i.image ?? null, active: true, created_at: now }
  const qty = existing ? adj : open
  const moves: StockMovement[] = qty !== 0 ? [{
    id: uuid(), product_id: product.id, kind: existing ? 'adjustment' : 'in', qty,
    reason: existing ? (i.adjustReason?.trim() || 'Stock adjustment') : 'Opening stock', ref_id: null, created_at: now
  }] : []
  await db.transaction('rw', db.products, db.stockMovements, db.outbox, async () => {
    await db.products.put(product)
    await enqueue('products', productPayload(product))
    if (moves.length) { await db.stockMovements.bulkPut(moves); await enqueue('stock_movements', moves) }
  })
  void syncNow()
  return null
}

export async function deleteProduct(id: string) {
  const p = await db.products.get(id)
  if (!p) return
  const now = new Date().toISOString()
  const next = { ...p, deleted_at: now, updated_at: now }
  await db.transaction('rw', db.products, db.outbox, async () => { await db.products.put(next); await enqueue('products', productPayload(next)) })
  void syncNow()
}

export async function saveCustomer(name: string, phone: string): Promise<Customer | string> {
  if (!name.trim()) return 'Customer name is required'
  const now = new Date().toISOString()
  const c: Customer = { id: uuid(), name: name.trim(), phone: phone.trim() || null, email: null, address: null, credit_balance: 0, created_at: now, updated_at: now, deleted_at: null }
  await db.transaction('rw', db.customers, db.outbox, async () => { await db.customers.put(c); await enqueue('customers', customerPayload(c)) })
  void syncNow()
  return c
}

/** CSV columns: name, sku, barcode, category, purchase_price, selling_price, stock_qty, low_stock_level.
 *  Existing products (matched by barcode, then sku) get updated prices/details; stock_qty only applies to NEW products. */
export async function importProducts(rows: string[][]) {
  const res = { created: 0, updated: 0, errors: [] as string[] }
  if (rows.length < 2) { res.errors.push('The file is empty'); return res }
  const head = rows[0].map(h => h.trim().toLowerCase())
  const get = (r: string[], n: string) => { const k = head.indexOf(n); return k < 0 ? '' : (r[k] ?? '').trim() }
  if (!head.includes('name')) { res.errors.push('Missing "name" column'); return res }
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i]
    const name = get(r, 'name')
    if (!name) { res.errors.push(`Row ${i + 1}: no name`); continue }
    const barcode = get(r, 'barcode'), sku = get(r, 'sku'), cat = get(r, 'category')
    let ex = barcode ? await db.products.where('barcode').equals(barcode).first() : undefined
    if (!ex && sku) ex = await db.products.filter(p => !p.deleted_at && p.sku === sku).first()
    const err = await saveProduct({
      id: ex?.id, name, sku, barcode, categoryId: cat ? await ensureCategory(cat) : null,
      purchase: num(get(r, 'purchase_price')), selling: num(get(r, 'selling_price')),
      low: get(r, 'low_stock_level') === '' ? 5 : num(get(r, 'low_stock_level')),
      openingStock: ex ? 0 : num(get(r, 'stock_qty'))
    })
    if (err) res.errors.push(`Row ${i + 1}: ${err}`); else if (ex) res.updated++; else res.created++
  }
  return res
}
