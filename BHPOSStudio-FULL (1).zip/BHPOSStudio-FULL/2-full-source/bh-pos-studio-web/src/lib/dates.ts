const p = (n: number) => String(n).padStart(2, '0')
export const ymd = (d: Date) => `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
export const startOfDay = (d: Date) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x }
export const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
export const monthStart = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1)
export type Preset = 'today' | '7d' | 'month' | 'lastmonth' | 'custom'
/** Returns [from, to) — `to` is exclusive. */
export function presetRange(k: Preset): [Date, Date] {
  const t = startOfDay(new Date()), tomorrow = addDays(t, 1)
  if (k === 'today') return [t, tomorrow]
  if (k === '7d') return [addDays(t, -6), tomorrow]
  if (k === 'month') return [monthStart(t), tomorrow]
  return [new Date(t.getFullYear(), t.getMonth() - 1, 1), monthStart(t)]
}
