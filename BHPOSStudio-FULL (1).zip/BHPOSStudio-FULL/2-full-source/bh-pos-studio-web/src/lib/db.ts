import Dexie, { type Table } from 'dexie'

export type Role = 'admin' | 'manager' | 'cashier'
export interface Setting { key: string; value: string; updatedAt: string }
export type Payload = object | object[]
export interface OutboxItem { id: string; table: string; payload: Payload; createdAt: number; attempts: number; lastError?: string }
export interface CachedProfile { id: string; email: string; fullName: string; role: Role; active: boolean }

// Local rows use the SAME column names as Supabase, so sync is a straight copy.
export interface Category { id: string; name: string; created_at: string }
export interface Product {
  id: string; name: string; sku: string | null; barcode: string | null; category_id: string | null
  purchase_price: number; selling_price: number; stock_qty: number; low_stock_level: number
  image_url: string | null; active: boolean; created_at: string; updated_at: string; deleted_at: string | null
}
export interface Customer {
  id: string; name: string; phone: string | null; email: string | null; address: string | null
  credit_balance: number; created_at: string; updated_at: string; deleted_at: string | null
}
export interface Sale {
  id: string; invoice_no: string; customer_id: string | null; cashier_id: string | null
  subtotal: number; discount: number; tax: number; total: number; paid: number; balance: number
  payment_method: string; status: string; device_id: string; created_at: string
}
export interface SaleItem {
  id: string; sale_id: string; product_id: string | null; name: string; qty: number
  unit_price: number; unit_cost: number; discount: number; line_total: number
}
export interface StockMovement {
  id: string; product_id: string; kind: string; qty: number; reason: string | null; ref_id: string | null; created_at: string
}

export interface Supplier { id: string; name: string; phone: string | null; email: string | null; address: string | null; created_at: string; updated_at: string; deleted_at: string | null }
export interface Purchase { id: string; supplier_id: string | null; reference: string | null; total: number; paid: number; created_by: string | null; created_at: string }
export interface PurchaseItem { id: string; purchase_id: string; product_id: string | null; name: string; qty: number; unit_cost: number; line_total: number }
export interface Expense { id: string; category: string; description: string | null; amount: number; expense_date: string; created_by: string | null; created_at: string; updated_at: string; deleted_at: string | null }
export interface Payment { id: string; sale_id: string | null; customer_id: string | null; amount: number; method: string; note: string | null; created_at: string }

export interface SupplierPayment { id: string; supplier_id: string; amount: number; method: string; note: string | null; created_by: string | null; created_at: string }
export interface SaleReturn { id: string; sale_id: string; invoice_no: string; customer_id: string | null; subtotal: number; discount: number; tax: number; total: number; refunded: number; credit_reduced: number; method: string; reason: string | null; restocked: boolean; created_by: string | null; created_at: string }
export interface SaleReturnItem { id: string; return_id: string; sale_item_id: string | null; product_id: string | null; name: string; qty: number; unit_price: number; unit_cost: number; line_total: number }

class BhDb extends Dexie {
  settings!: Table<Setting, string>
  outbox!: Table<OutboxItem, string>
  profile!: Table<CachedProfile, string>
  categories!: Table<Category, string>
  products!: Table<Product, string>
  customers!: Table<Customer, string>
  sales!: Table<Sale, string>
  saleItems!: Table<SaleItem, string>
  stockMovements!: Table<StockMovement, string>
  suppliers!: Table<Supplier, string>
  purchases!: Table<Purchase, string>
  purchaseItems!: Table<PurchaseItem, string>
  expenses!: Table<Expense, string>
  payments!: Table<Payment, string>
  saleReturns!: Table<SaleReturn, string>
  supplierPayments!: Table<SupplierPayment, string>
  saleReturnItems!: Table<SaleReturnItem, string>
  constructor() {
    super('bh_pos_studio')
    this.version(1).stores({
      settings: 'key', outbox: 'id, table, createdAt', profile: 'id',
      products: 'id, barcode, name', customers: 'id, name, phone'
    })
    this.version(2).stores({
      products: 'id, barcode, name, category_id',
      categories: 'id, name',
      sales: 'id, invoice_no, created_at',
      saleItems: 'id, sale_id',
      stockMovements: 'id, product_id'
    })
    this.version(3).stores({
      sales: 'id, invoice_no, created_at, customer_id',
      stockMovements: 'id, product_id, created_at',
      suppliers: 'id, name',
      purchases: 'id, supplier_id, created_at',
      purchaseItems: 'id, purchase_id',
      expenses: 'id, expense_date',
      payments: 'id, customer_id, created_at'
    })
    this.version(4).stores({
      saleReturns: 'id, sale_id, created_at',
      saleReturnItems: 'id, return_id'
    })
    this.version(5).stores({
      supplierPayments: 'id, supplier_id, created_at'
    })
  }
}
export const db = new BhDb()
