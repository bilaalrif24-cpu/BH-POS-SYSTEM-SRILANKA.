import type { Sale, SaleItem } from './db'
import type { Biz, Buyer } from './invoice'

const n2 = (n: number) => Number(n).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
const ascii = (s: string) => s.replace(/[^\x20-\x7E]/g, '?') // basic printers only know ASCII
const METHOD: Record<string, string> = { cash: 'Cash', card: 'Card', bank_transfer: 'Bank', credit: 'Credit' }

class Esc {
  private b: number[] = []
  raw(...x: number[]) { this.b.push(...x); return this }
  text(s = '') { for (const ch of ascii(s)) this.b.push(ch.charCodeAt(0)); this.b.push(10); return this }
  init() { return this.raw(0x1b, 0x40) }
  align(a: 0 | 1) { return this.raw(0x1b, 0x61, a) }
  bold(on: boolean) { return this.raw(0x1b, 0x45, on ? 1 : 0) }
  big(on: boolean) { return this.raw(0x1d, 0x21, on ? 0x11 : 0) }
  feed(n: number) { return this.raw(0x1b, 0x64, n) }
  cut() { return this.raw(0x1d, 0x56, 0x42, 0) } // ignored by printers without a cutter
  bytes() { return new Uint8Array(this.b) }
}

function wrap(s: string, w: number) {
  const out: string[] = []; let cur = ''
  for (const word of ascii(s).split(' ')) {
    if ((cur + ' ' + word).trim().length > w) { if (cur) out.push(cur); cur = word.slice(0, w) } else cur = (cur + ' ' + word).trim()
  }
  if (cur) out.push(cur)
  return out
}

export function receiptEsc(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const w = biz.paper === '58' ? 32 : 48
  const line = '-'.repeat(w)
  const lr = (l: string, r: string) => { const left = ascii(l).slice(0, Math.max(0, w - r.length - 1)); return left + ' '.repeat(w - left.length - r.length) + r }
  const e = new Esc().init().align(1).big(true).bold(true)
  wrap(biz.name, Math.floor(w / 2)).forEach(t => e.text(t))
  e.big(false).bold(false)
  if (biz.address) wrap(biz.address, w).forEach(t => e.text(t))
  if (biz.phone) e.text(biz.phone)
  e.align(0).text(line).text('Invoice: ' + sale.invoice_no).text('Date: ' + new Date(sale.created_at).toLocaleString('en-LK'))
  if (buyer) e.text('Customer: ' + buyer.name)
  e.text(line)
  for (const i of items) {
    wrap(i.name, w).forEach(t => e.text(t))
    e.text(lr(`  ${i.qty} x ${n2(i.unit_price)}`, n2(i.line_total)))
  }
  e.text(line).text(lr('Subtotal', n2(sale.subtotal)))
  if (sale.discount > 0) e.text(lr('Discount', '-' + n2(sale.discount)))
  if (sale.tax > 0) e.text(lr('Tax', n2(sale.tax)))
  e.bold(true).text(lr('TOTAL (LKR)', n2(sale.total))).bold(false)
  e.text(lr('Paid ' + (METHOD[sale.payment_method] ?? ''), n2(sale.paid)))
  if (sale.balance > 0) e.bold(true).text(lr('BALANCE DUE', n2(sale.balance))).bold(false)
  e.text(line).align(1)
  if (biz.footer) wrap(biz.footer, w).forEach(t => e.text(t))
  e.text('BH POS STUDIO by BH GRAPHICS').feed(4).cut()
  return e.bytes()
}

export function testEsc(biz: Biz) {
  const w = biz.paper === '58' ? 32 : 48
  return new Esc().init().align(1).big(true).bold(true).text('BH POS STUDIO').big(false).bold(false)
    .text('Printer test OK').text(`${biz.paper} mm paper (${w} chars)`).text('-'.repeat(w)).text('0123456789 ABCDEFGHIJ').feed(4).cut().bytes()
}
