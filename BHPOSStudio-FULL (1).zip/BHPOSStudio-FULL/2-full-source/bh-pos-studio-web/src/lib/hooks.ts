import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from './db'

export function useOnline() {
  const [online, setOnline] = useState(navigator.onLine)
  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false)
    window.addEventListener('online', on); window.addEventListener('offline', off)
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [])
  return online
}

export function useSetting(key: string, fallback: string) {
  const row = useLiveQuery(() => db.settings.get(key), [key])
  return row?.value ?? fallback
}

export const SETTING_DEFAULTS: Record<string, string> = {
  business_name: 'My Business', business_address: '', business_phone: '',
  tax_percent: '0', receipt_footer: 'Thank you for your business!', paper_width: '80'
}

export function useSettingsMap() {
  const rows = useLiveQuery(() => db.settings.toArray(), [])
  return rows ? (Object.fromEntries(rows.map(r => [r.key, r.value])) as Record<string, string>) : undefined
}

export function useBiz() {
  const s = useSettingsMap()
  const g = (k: string) => s?.[k] ?? SETTING_DEFAULTS[k]
  return {
    name: g('business_name'), address: g('business_address'), phone: g('business_phone'), footer: g('receipt_footer'),
    paper: (g('paper_width') === '58' ? '58' : '80') as '58' | '80',
    taxPct: Math.min(100, Math.max(0, Number(g('tax_percent')) || 0))
  }
}
