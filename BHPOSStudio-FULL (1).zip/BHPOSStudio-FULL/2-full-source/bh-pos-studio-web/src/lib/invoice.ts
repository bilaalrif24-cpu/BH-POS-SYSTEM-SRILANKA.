import type { Sale, SaleItem } from './db'
import { fmt } from './money'

export interface Biz { name: string; address: string; phone: string; footer: string; paper: '58' | '80' }
export interface Buyer { name: string; phone: string | null }

const METHOD: Record<string, string> = { cash: 'Cash', card: 'Card', bank_transfer: 'Bank transfer', credit: 'Credit' }
const esc = (s: string) => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } as Record<string, string>)[c])
const when = (s: Sale) => new Date(s.created_at).toLocaleString('en-LK')

export function receiptHtml(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const w = Number(biz.paper)
  const rows = items.map(i => `<tr><td colspan="2">${esc(i.name)}</td></tr><tr><td>${i.qty} x ${fmt(i.unit_price)}</td><td class="r">${fmt(i.line_total)}</td></tr>`).join('')
  const line = (a: string, b: string, bold = false) => `<tr${bold ? ' class="b"' : ''}><td>${a}</td><td class="r">${b}</td></tr>`
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(sale.invoice_no)}</title><style>
@page{size:${w}mm auto;margin:0}body{width:${w - 6}mm;margin:0 3mm;font:12px/1.35 monospace;color:#000}
h1{font-size:15px;margin:6px 0 0;text-align:center}.c{text-align:center}.r{text-align:right}table{width:100%;border-collapse:collapse}
.b td{font-weight:bold;font-size:13px}hr{border:0;border-top:1px dashed #000;margin:6px 0}</style></head><body>
<h1>${esc(biz.name)}</h1><div class="c">${esc(biz.address)}<br>${esc(biz.phone)}</div><hr>
<div>Invoice: ${esc(sale.invoice_no)}<br>Date: ${esc(when(sale))}${buyer ? `<br>Customer: ${esc(buyer.name)}` : ''}</div><hr>
<table>${rows}</table><hr><table>
${line('Subtotal', fmt(sale.subtotal))}${sale.discount > 0 ? line('Discount', '-' + fmt(sale.discount)) : ''}${sale.tax > 0 ? line('Tax', fmt(sale.tax)) : ''}
${line('TOTAL', fmt(sale.total), true)}${line('Paid (' + (METHOD[sale.payment_method] ?? sale.payment_method) + ')', fmt(sale.paid))}${sale.balance > 0 ? line('Balance due', fmt(sale.balance), true) : ''}
</table><hr><div class="c">${esc(biz.footer)}<br>BH POS STUDIO by BH GRAPHICS</div></body></html>`
}

export function printReceipt(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const f = document.createElement('iframe')
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'
  document.body.appendChild(f)
  const d = f.contentWindow!.document
  d.open(); d.write(receiptHtml(sale, items, biz, buyer)); d.close()
  setTimeout(() => { f.contentWindow!.focus(); f.contentWindow!.print(); setTimeout(() => f.remove(), 1500) }, 250)
}

export function whatsappUrl(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const lines = [
    `*${biz.name}*`, `Invoice ${sale.invoice_no}`, when(sale), '',
    ...items.map(i => `${i.name} — ${i.qty} x ${fmt(i.unit_price)} = ${fmt(i.line_total)}`), '',
    ...(sale.discount > 0 ? [`Discount: -${fmt(sale.discount)}`] : []), ...(sale.tax > 0 ? [`Tax: ${fmt(sale.tax)}`] : []),
    `*Total: ${fmt(sale.total)}*`, `Paid: ${fmt(sale.paid)}`, ...(sale.balance > 0 ? [`Balance due: ${fmt(sale.balance)}`] : []), '', biz.footer
  ]
  let phone = (buyer?.phone ?? '').replace(/\D/g, '')
  if (phone.startsWith('0')) phone = '94' + phone.slice(1) // Sri Lanka local format
  return `https://wa.me/${phone}?text=${encodeURIComponent(lines.join('\n'))}`
}

export async function downloadPdf(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  let y = 20
  doc.setFont('helvetica', 'bold').setFontSize(20).text(biz.name, 14, y)
  doc.setFont('helvetica', 'normal').setFontSize(10)
  if (biz.address) doc.text(biz.address, 14, (y += 6))
  if (biz.phone) doc.text(biz.phone, 14, (y += 5))
  doc.setFont('helvetica', 'bold').setFontSize(16).text('INVOICE', 196, 20, { align: 'right' })
  doc.setFont('helvetica', 'normal').setFontSize(10)
  doc.text(sale.invoice_no, 196, 27, { align: 'right' }); doc.text(when(sale), 196, 32, { align: 'right' })
  y = Math.max(y, 32) + 10
  if (buyer) { doc.text(`Bill to: ${buyer.name}${buyer.phone ? ' · ' + buyer.phone : ''}`, 14, y); y += 8 }
  doc.setFont('helvetica', 'bold'); doc.text('Item', 14, y); doc.text('Qty', 120, y, { align: 'right' }); doc.text('Price', 155, y, { align: 'right' }); doc.text('Total', 196, y, { align: 'right' })
  doc.line(14, y + 2, 196, y + 2); y += 8; doc.setFont('helvetica', 'normal')
  for (const i of items) {
    if (y > 265) { doc.addPage(); y = 20 }
    doc.text(i.name.slice(0, 55), 14, y); doc.text(String(i.qty), 120, y, { align: 'right' })
    doc.text(fmt(i.unit_price), 155, y, { align: 'right' }); doc.text(fmt(i.line_total), 196, y, { align: 'right' }); y += 6
  }
  doc.line(14, y, 196, y); y += 7
  const row = (a: string, b: string, bold = false) => { doc.setFont('helvetica', bold ? 'bold' : 'normal'); doc.text(a, 140, y); doc.text(b, 196, y, { align: 'right' }); y += 6 }
  row('Subtotal', fmt(sale.subtotal))
  if (sale.discount > 0) row('Discount', '-' + fmt(sale.discount))
  if (sale.tax > 0) row('Tax', fmt(sale.tax))
  row('TOTAL', fmt(sale.total), true)
  row('Paid (' + (METHOD[sale.payment_method] ?? sale.payment_method) + ')', fmt(sale.paid))
  if (sale.balance > 0) row('Balance due', fmt(sale.balance), true)
  doc.setFont('helvetica', 'normal').setFontSize(9).text(biz.footer, 105, 285, { align: 'center' })
  doc.save(`${sale.invoice_no}.pdf`)
}
