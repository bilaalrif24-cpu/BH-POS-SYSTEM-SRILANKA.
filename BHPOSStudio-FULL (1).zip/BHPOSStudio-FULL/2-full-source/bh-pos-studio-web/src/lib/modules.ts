import { LayoutDashboard, ShoppingCart, Package, Boxes, Users, Truck, Wallet, BarChart3, Settings, type LucideIcon } from 'lucide-react'
import type { Role } from './db'

const all: Role[] = ['admin', 'manager', 'cashier']
const staff: Role[] = ['admin', 'manager']

export interface AppModule { path: string; title: string; icon: LucideIcon; roles: Role[]; phase?: string; blurb?: string; features?: string[] }

export const MODULES: AppModule[] = [
  { path: 'dashboard', title: 'Dashboard', icon: LayoutDashboard, roles: all },
  { path: 'pos', title: 'POS Billing', icon: ShoppingCart, roles: all, phase: 'Phase 2', blurb: 'Fast billing with cart, discounts and payments in LKR.',
    features: ['Product search and barcode scanning', 'Cash, card, bank transfer and credit sales', 'Invoice, PDF, WhatsApp and receipt printing'] },
  { path: 'products', title: 'Products', icon: Package, roles: staff, phase: 'Phase 2', blurb: 'Your full product catalogue.',
    features: ['Add, edit, delete, categories and images', 'Barcodes, purchase and selling prices', 'CSV import and export'] },
  { path: 'inventory', title: 'Inventory', icon: Boxes, roles: staff, phase: 'Phase 3', blurb: 'Real-time stock control.',
    features: ['Stock-in, stock-out and adjustments', 'Low-stock alerts', 'Inventory reports and valuation'] },
  { path: 'customers', title: 'Customers', icon: Users, roles: all, phase: 'Phase 3', blurb: 'Customer profiles and credit.',
    features: ['Profiles and phone numbers', 'Purchase and payment history', 'Outstanding balances'] },
  { path: 'purchases', title: 'Purchases', icon: Truck, roles: staff, phase: 'Phase 3', blurb: 'Supplier purchases that update stock.',
    features: ['Suppliers and purchase records', 'Automatic stock updates'] },
  { path: 'expenses', title: 'Expenses', icon: Wallet, roles: staff, phase: 'Phase 3', blurb: 'Track business spending.',
    features: ['Record and categorise expenses', 'Feeds profit and loss'] },
  { path: 'reports', title: 'Reports', icon: BarChart3, roles: staff, phase: 'Phase 3', blurb: 'Business reports and exports.',
    features: ['Daily and monthly sales', 'Profit and loss, product performance', 'PDF and CSV exports'] },
  { path: 'settings', title: 'Settings', icon: Settings, roles: all }
]
