export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100
export const fmt = (n: number) =>
  'LKR ' + Number(n || 0).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
export const uuid = () => crypto.randomUUID()
