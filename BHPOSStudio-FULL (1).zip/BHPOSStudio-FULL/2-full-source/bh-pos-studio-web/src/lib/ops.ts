import { db, type Customer, type Expense, type Payment, type Product, type Purchase, type PurchaseItem, type StockMovement, type Supplier } from './db'
import { customerPayload, productPayload } from './catalog'
import { enqueue, syncNow } from './sync'
import { round2, uuid } from './money'

const rec = (x: unknown) => x as Record<string, unknown>
const recs = (x: unknown) => x as Record<string, unknown>[]

export async function saveCustomerFull(i: { id?: string; name: string; phone: string; email: string; address: string }): Promise<string | null> {
  if (!i.name.trim()) return 'Customer name is required'
  const now = new Date().toISOString()
  const ex = i.id ? await db.customers.get(i.id) : undefined
  const c: Customer = {
    id: ex?.id ?? uuid(), name: i.name.trim(), phone: i.phone.trim() || null, email: i.email.trim() || null, address: i.address.trim() || null,
    credit_balance: ex?.credit_balance ?? 0, created_at: ex?.created_at ?? now, updated_at: now, deleted_at: null
  }
  await db.transaction('rw', db.customers, db.outbox, async () => { await db.customers.put(c); await enqueue('customers', customerPayload(c)) })
  void syncNow()
  return null
}

export async function deleteCustomer(id: string) {
  const c = await db.customers.get(id)
  if (!c) return
  const n = { ...c, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() }
  await db.transaction('rw', db.customers, db.outbox, async () => { await db.customers.put(n); await enqueue('customers', customerPayload(n)) })
  void syncNow()
}

/** A customer pays off (part of) their credit. */
export async function receivePayment(customerId: string, amount: number, method: string, note: string): Promise<string | null> {
  const c = await db.customers.get(customerId)
  if (!c) return 'Customer not found'
  if (!(amount > 0)) return 'Enter an amount above 0'
  const amt = round2(Math.min(amount, Number(c.credit_balance)))
  if (amt <= 0) return 'This customer has no outstanding balance'
  const p: Payment = { id: uuid(), sale_id: null, customer_id: customerId, amount: amt, method, note: note.trim() || null, created_at: new Date().toISOString() }
  await db.transaction('rw', db.customers, db.payments, db.outbox, async () => {
    await db.payments.add(p)
    await db.customers.where('id').equals(customerId).modify(x => { x.credit_balance = round2(Number(x.credit_balance) - amt) })
    await enqueue('payments', rec(p))
  })
  void syncNow()
  return null
}

export async function moveStock(productId: string, kind: 'in' | 'out' | 'adjustment', qty: number, reason: string): Promise<string | null> {
  const p = await db.products.get(productId)
  if (!p) return 'Product not found'
  if (kind !== 'adjustment' && !(qty > 0)) return 'Enter a quantity above 0'
  if (kind === 'adjustment' && !(qty >= 0)) return 'Counted stock cannot be negative'
  const stock = Number(p.stock_qty)
  const delta = kind === 'in' ? qty : kind === 'out' ? -qty : round2(qty - stock)
  if (delta === 0) return 'No change to record'
  if (stock + delta < 0) return `Not enough stock (${stock} available)`
  const m: StockMovement = { id: uuid(), product_id: productId, kind, qty: delta, reason: reason.trim() || (kind === 'in' ? 'Stock in' : kind === 'out' ? 'Stock out' : 'Stock count'), ref_id: null, created_at: new Date().toISOString() }
  await db.transaction('rw', db.products, db.stockMovements, db.outbox, async () => {
    await db.stockMovements.add(m)
    await db.products.where('id').equals(productId).modify(x => { x.stock_qty = round2(Number(x.stock_qty) + delta) })
    await enqueue('stock_movements', recs([m]))
  })
  void syncNow()
  return null
}

export async function saveSupplier(i: { id?: string; name: string; phone: string; address: string }): Promise<Supplier | string> {
  if (!i.name.trim()) return 'Supplier name is required'
  const now = new Date().toISOString()
  const ex = i.id ? await db.suppliers.get(i.id) : undefined
  const s: Supplier = { id: ex?.id ?? uuid(), name: i.name.trim(), phone: i.phone.trim() || null, email: ex?.email ?? null, address: i.address.trim() || null, created_at: ex?.created_at ?? now, updated_at: now, deleted_at: null }
  await db.transaction('rw', db.suppliers, db.outbox, async () => { await db.suppliers.put(s); await enqueue('suppliers', rec(s)) })
  void syncNow()
  return s
}

export interface PurchaseLine { product: Product; qty: number; cost: number }

/** Adds stock from a supplier purchase. Everything saves locally first and uploads in FK order. */
export async function createPurchase(i: { supplierId: string | null; reference: string; lines: PurchaseLine[]; paid: number; updateCost: boolean; userId: string }): Promise<string | null> {
  if (!i.lines.length) return 'Add at least one item'
  if (i.lines.some(l => !(l.qty > 0) || l.cost < 0)) return 'Check quantities and costs'
  const iso = new Date().toISOString()
  const total = round2(i.lines.reduce((s, l) => s + l.qty * l.cost, 0))
  const purchase: Purchase = { id: uuid(), supplier_id: i.supplierId, reference: i.reference.trim() || null, total, paid: round2(Math.min(Math.max(i.paid, 0), total)), created_by: i.userId, created_at: iso }
  const items: PurchaseItem[] = i.lines.map(l => ({ id: uuid(), purchase_id: purchase.id, product_id: l.product.id, name: l.product.name, qty: l.qty, unit_cost: l.cost, line_total: round2(l.qty * l.cost) }))
  const moves: StockMovement[] = i.lines.map(l => ({ id: uuid(), product_id: l.product.id, kind: 'purchase', qty: l.qty, reason: 'Purchase' + (purchase.reference ? ' ' + purchase.reference : ''), ref_id: purchase.id, created_at: iso }))
  await db.transaction('rw', [db.products, db.purchases, db.purchaseItems, db.stockMovements, db.outbox], async () => {
    for (const l of i.lines) {
      const p = await db.products.get(l.product.id)
      if (!p) continue
      const np = { ...p, stock_qty: round2(Number(p.stock_qty) + l.qty), ...(i.updateCost && l.cost !== Number(p.purchase_price) ? { purchase_price: l.cost, updated_at: iso } : {}) }
      await db.products.put(np)
      if (np.purchase_price !== p.purchase_price) await enqueue('products', rec(productPayload(np)))
    }
    await db.purchases.add(purchase); await db.purchaseItems.bulkAdd(items); await db.stockMovements.bulkAdd(moves)
    await enqueue('purchases', rec(purchase)); await enqueue('purchase_items', recs(items)); await enqueue('stock_movements', recs(moves))
  })
  void syncNow()
  return null
}

export async function saveExpense(i: { id?: string; category: string; description: string; amount: number; date: string; userId: string }): Promise<string | null> {
  if (!i.category.trim()) return 'Choose or type a category'
  if (!(i.amount > 0)) return 'Enter an amount above 0'
  if (!i.date) return 'Choose a date'
  const now = new Date().toISOString()
  const ex = i.id ? await db.expenses.get(i.id) : undefined
  const e: Expense = { id: ex?.id ?? uuid(), category: i.category.trim(), description: i.description.trim() || null, amount: round2(i.amount), expense_date: i.date, created_by: ex?.created_by ?? i.userId, created_at: ex?.created_at ?? now, updated_at: now, deleted_at: null }
  await db.transaction('rw', db.expenses, db.outbox, async () => { await db.expenses.put(e); await enqueue('expenses', rec(e)) })
  void syncNow()
  return null
}

export async function deleteExpense(id: string) {
  const e = await db.expenses.get(id)
  if (!e) return
  const n = { ...e, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() }
  await db.transaction('rw', db.expenses, db.outbox, async () => { await db.expenses.put(n); await enqueue('expenses', rec(n)) })
  void syncNow()
}

/** Pay a supplier (reduces what we owe them). Append-only record, uploaded like any other transaction. */
export async function paySupplier(supplierId: string, amount: number, method: string, note: string, userId: string): Promise<string | null> {
  if (!(amount > 0)) return 'Enter an amount above 0'
  const purchases = await db.purchases.where('supplier_id').equals(supplierId).toArray()
  const paid = await db.supplierPayments.where('supplier_id').equals(supplierId).toArray()
  const owed = round2(purchases.reduce((s, p) => s + Number(p.total) - Number(p.paid), 0) - paid.reduce((s, p) => s + Number(p.amount), 0))
  if (owed <= 0) return 'Nothing is owed to this supplier'
  if (amount > owed) return `You only owe ${owed.toFixed(2)}`
  const p = { id: uuid(), supplier_id: supplierId, amount: round2(amount), method, note: note.trim() || null, created_by: userId, created_at: new Date().toISOString() }
  await db.transaction('rw', db.supplierPayments, db.outbox, async () => { await db.supplierPayments.add(p); await enqueue('supplier_payments', p) })
  void syncNow()
  return null
}
