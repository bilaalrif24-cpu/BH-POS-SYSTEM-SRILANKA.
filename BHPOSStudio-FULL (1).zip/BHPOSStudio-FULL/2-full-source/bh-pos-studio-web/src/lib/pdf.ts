export async function tablePdf(file: string, title: string, sub: string, head: string[], rows: string[][]) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: head.length > 5 ? 'landscape' : 'portrait' })
  const W = doc.internal.pageSize.getWidth() - 28, H = doc.internal.pageSize.getHeight()
  const cw = W / head.length
  let y = 18
  doc.setFont('helvetica', 'bold').setFontSize(14).text(title, 14, y)
  doc.setFont('helvetica', 'normal').setFontSize(9).text(sub, 14, (y += 6))
  y += 8
  const header = () => {
    doc.setFont('helvetica', 'bold').setFontSize(8)
    head.forEach((h, i) => doc.text(h, 14 + i * cw, y))
    doc.line(14, y + 1.5, 14 + W, y + 1.5); y += 6
    doc.setFont('helvetica', 'normal')
  }
  header()
  for (const r of rows) {
    if (y > H - 15) { doc.addPage(); y = 18; header() }
    r.forEach((c, i) => doc.text(String(c).slice(0, Math.floor(cw / 1.6)), 14 + i * cw, y))
    y += 5
  }
  doc.save(file)
}
