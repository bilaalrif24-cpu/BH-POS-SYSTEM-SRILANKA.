import type { Sale, SaleItem } from './db'
import type { Biz, Buyer } from './invoice'
import { receiptEsc, testEsc } from './escpos'
import { rasterReceipt, rasterTest } from './raster'

export type PrintMode = 'text' | 'image'
export const getPrintMode = (): PrintMode => (localStorage.getItem('bh-bt-mode') === 'image' ? 'image' : 'text')
export const setPrintMode = (m: PrintMode) => localStorage.setItem('bh-bt-mode', m)

export const receiptBytes = (sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) =>
  getPrintMode() === 'image' ? rasterReceipt(sale, items, biz, buyer) : receiptEsc(sale, items, biz, buyer)
export const testBytes = (biz: Biz) => (getPrintMode() === 'image' ? rasterTest(biz) : testEsc(biz))
