/* Image-mode receipts: the receipt is drawn on a canvas (so ANY language the phone can display — Sinhala, Tamil, English —
   prints correctly) and sent to the printer as a 1-bit ESC/POS raster image. */
import type { Sale, SaleItem } from './db'
import type { Biz, Buyer } from './invoice'

interface L { t?: string; r?: string; align?: 'l' | 'c'; bold?: boolean; size?: number; rule?: boolean; gap?: number }
const FONT = '"Noto Sans Sinhala","Iskoola Pota","Nirmala UI","Noto Sans Tamil","Latha",system-ui,sans-serif'
const n2 = (n: number) => Number(n).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
const METHOD: Record<string, string> = { cash: 'Cash', card: 'Card', bank_transfer: 'Bank', credit: 'Credit' }

function wrapText(ctx: CanvasRenderingContext2D, text: string, max: number) {
  const rows: string[] = []
  let cur = ''
  const push = (w: string) => {
    if (ctx.measureText(w).width <= max) { cur = w; return }
    let piece = ''                                  // a single word wider than the paper: split by characters
    for (const ch of w) { if (ctx.measureText(piece + ch).width > max) { rows.push(piece); piece = ch } else piece += ch }
    cur = piece
  }
  for (const word of text.split(' ')) {
    const next = cur ? cur + ' ' + word : word
    if (ctx.measureText(next).width <= max) cur = next
    else { if (cur) rows.push(cur); push(word) }
  }
  if (cur) rows.push(cur)
  return rows.length ? rows : ['']
}

function render(lines: L[], w: number): Uint8Array {
  const PAD = 4
  const c = document.createElement('canvas')
  c.width = w; c.height = 10
  const ctx = c.getContext('2d', { willReadFrequently: true })!
  const draw = (doDraw: boolean) => {
    let y = 8
    for (const l of lines) {
      const size = l.size ?? (w > 400 ? 24 : 21)
      ctx.font = `${l.bold ? 'bold ' : ''}${size}px ${FONT}`
      ctx.textBaseline = 'top'
      if (l.gap) { y += l.gap; continue }
      if (l.rule) { if (doDraw) ctx.fillRect(0, y + Math.round(size / 2), w, 2); y += size; continue }
      const lh = Math.round(size * 1.35)
      if (l.r !== undefined) {
        const rw = ctx.measureText(l.r).width
        let left = l.t ?? ''
        while (left && ctx.measureText(left).width > w - rw - PAD * 2 - 10) left = left.slice(0, -1)
        if (doDraw) { ctx.textAlign = 'left'; ctx.fillText(left, PAD, y); ctx.textAlign = 'right'; ctx.fillText(l.r, w - PAD, y) }
        y += lh
      } else {
        for (const row of wrapText(ctx, l.t ?? '', w - PAD * 2)) {
          if (doDraw) { ctx.textAlign = l.align === 'c' ? 'center' : 'left'; ctx.fillText(row, l.align === 'c' ? w / 2 : PAD, y) }
          y += lh
        }
      }
    }
    return y + 8
  }
  const h = draw(false)
  c.height = h                                     // resizing resets the canvas, so paint again from scratch
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.fillStyle = '#000'
  draw(true)
  const px = ctx.getImageData(0, 0, w, h).data
  const bpr = w / 8
  const out: number[] = [0x1b, 0x40]
  for (let y0 = 0; y0 < h; y0 += 200) {            // bands of 200 rows: friendlier to small printer buffers
    const bh = Math.min(200, h - y0)
    out.push(0x1d, 0x76, 0x30, 0, bpr & 255, bpr >> 8, bh & 255, bh >> 8)
    for (let y = y0; y < y0 + bh; y++) {
      for (let bx = 0; bx < bpr; bx++) {
        let byte = 0
        for (let k = 0; k < 8; k++) {
          const i = (y * w + bx * 8 + k) * 4
          if (px[i] * 0.3 + px[i + 1] * 0.59 + px[i + 2] * 0.11 < 140) byte |= 0x80 >> k
        }
        out.push(byte)
      }
    }
  }
  out.push(0x1b, 0x64, 4, 0x1d, 0x56, 0x42, 0)
  return new Uint8Array(out)
}

const width = (b: Biz) => (b.paper === '58' ? 384 : 576)

export function rasterReceipt(sale: Sale, items: SaleItem[], biz: Biz, buyer: Buyer | null) {
  const L: L[] = [
    { t: biz.name, align: 'c', bold: true, size: 30 },
    ...(biz.address ? [{ t: biz.address, align: 'c' as const }] : []), ...(biz.phone ? [{ t: biz.phone, align: 'c' as const }] : []),
    { rule: true }, { t: 'Invoice: ' + sale.invoice_no }, { t: new Date(sale.created_at).toLocaleString('en-LK') },
    ...(buyer ? [{ t: 'Customer: ' + buyer.name }] : []), { rule: true },
    ...items.flatMap((i): L[] => [{ t: i.name }, { t: `   ${i.qty} x ${n2(i.unit_price)}`, r: n2(i.line_total) }]),
    { rule: true }, { t: 'Subtotal', r: n2(sale.subtotal) },
    ...(sale.discount > 0 ? [{ t: 'Discount', r: '-' + n2(sale.discount) }] : []), ...(sale.tax > 0 ? [{ t: 'Tax', r: n2(sale.tax) }] : []),
    { t: 'TOTAL (LKR)', r: n2(sale.total), bold: true, size: 26 }, { t: 'Paid ' + (METHOD[sale.payment_method] ?? ''), r: n2(sale.paid) },
    ...(sale.balance > 0 ? [{ t: 'BALANCE DUE', r: n2(sale.balance), bold: true }] : []),
    { rule: true }, ...(biz.footer ? [{ t: biz.footer, align: 'c' as const }] : []), { t: 'BH POS STUDIO by BH GRAPHICS', align: 'c', size: 18 }
  ]
  return render(L, width(biz))
}

export function rasterTest(biz: Biz) {
  return render([
    { t: 'BH POS STUDIO', align: 'c', bold: true, size: 30 }, { t: 'Image mode test OK', align: 'c' }, { rule: true },
    { t: 'English: Thank you', align: 'c' }, { t: 'සිංහල: ස්තූතියි', align: 'c' }, { t: 'தமிழ்: நன்றி', align: 'c' }, { rule: true }
  ], width(biz))
}
