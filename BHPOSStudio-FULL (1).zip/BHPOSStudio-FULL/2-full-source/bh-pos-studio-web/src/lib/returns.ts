import { db, type Sale, type SaleItem, type SaleReturn, type SaleReturnItem, type StockMovement } from './db'
import { enqueue, syncNow } from './sync'
import { round2, uuid } from './money'

const recs = (x: unknown) => x as Record<string, unknown>[]

/** Proportional share of the sale's discount and tax for the returned lines. */
export function computeReturn(sale: Sale, lines: { item: SaleItem; qty: number }[]) {
  const lineSum = round2(lines.reduce((s, l) => s + l.qty * Number(l.item.unit_price), 0))
  const discount = sale.subtotal > 0 ? round2((lineSum * sale.discount) / sale.subtotal) : 0
  const base = sale.subtotal - sale.discount
  const tax = base > 0 ? round2(((lineSum - discount) * sale.tax) / base) : 0
  return { lineSum, discount, tax, total: round2(lineSum - discount + tax) }
}

export async function returnedQty(saleId: string) {
  const rs = await db.saleReturns.where('sale_id').equals(saleId).toArray()
  const its = await db.saleReturnItems.where('return_id').anyOf(rs.map(r => r.id)).toArray()
  const m = new Map<string, number>()
  its.forEach(i => { if (i.sale_item_id) m.set(i.sale_item_id, (m.get(i.sale_item_id) ?? 0) + Number(i.qty)) })
  return { map: m, creditUsed: round2(rs.reduce((s, r) => s + Number(r.credit_reduced), 0)) }
}

/** Return/void. Append-only: a new return record + stock movements. Credit owed on the sale is cancelled first; the rest is refunded. */
export async function createReturn(i: { sale: Sale; items: SaleItem[]; qtys: Record<string, number>; method: string; reason: string; restock: boolean; userId: string }): Promise<{ total: number; refunded: number; credit: number } | string> {
  const { map, creditUsed } = await returnedQty(i.sale.id)
  const lines = i.items.map(item => ({ item, qty: Number(i.qtys[item.id]) || 0 })).filter(l => l.qty > 0)
  if (!lines.length) return 'Choose at least one item to return'
  for (const l of lines) {
    const left = Number(l.item.qty) - (map.get(l.item.id) ?? 0)
    if (l.qty > left) return `Only ${left} of "${l.item.name}" can still be returned`
  }
  const c = computeReturn(i.sale, lines)
  const customer = i.sale.customer_id ? await db.customers.get(i.sale.customer_id) : undefined
  const allowance = Math.max(0, Number(i.sale.balance) - creditUsed)
  const credit = customer ? round2(Math.min(c.total, allowance, Math.max(0, Number(customer.credit_balance)))) : 0
  const refunded = round2(c.total - credit)
  const iso = new Date().toISOString()
  const ret: SaleReturn = {
    id: uuid(), sale_id: i.sale.id, invoice_no: i.sale.invoice_no, customer_id: i.sale.customer_id, subtotal: c.lineSum, discount: c.discount, tax: c.tax,
    total: c.total, refunded, credit_reduced: credit, method: i.method, reason: i.reason.trim() || null, restocked: i.restock, created_by: i.userId, created_at: iso
  }
  const items: SaleReturnItem[] = lines.map(l => ({ id: uuid(), return_id: ret.id, sale_item_id: l.item.id, product_id: l.item.product_id, name: l.item.name, qty: l.qty, unit_price: l.item.unit_price, unit_cost: l.item.unit_cost, line_total: round2(l.qty * l.item.unit_price) }))
  const moves: StockMovement[] = i.restock ? items.filter(x => x.product_id).map(x => ({ id: uuid(), product_id: x.product_id!, kind: 'return', qty: x.qty, reason: 'Return ' + i.sale.invoice_no, ref_id: ret.id, created_at: iso })) : []
  await db.transaction('rw', [db.saleReturns, db.saleReturnItems, db.stockMovements, db.products, db.customers, db.outbox], async () => {
    await db.saleReturns.add(ret); await db.saleReturnItems.bulkAdd(items)
    if (moves.length) {
      await db.stockMovements.bulkAdd(moves)
      for (const m of moves) await db.products.where('id').equals(m.product_id).modify(p => { p.stock_qty = round2(Number(p.stock_qty) + m.qty) })
    }
    if (credit > 0 && i.sale.customer_id) await db.customers.where('id').equals(i.sale.customer_id).modify(x => { x.credit_balance = round2(Number(x.credit_balance) - credit) })
    await enqueue('sale_returns', ret as unknown as Record<string, unknown>)
    await enqueue('sale_return_items', recs(items))
    if (moves.length) await enqueue('stock_movements', recs(moves))
  })
  void syncNow()
  return { total: c.total, refunded, credit }
}
