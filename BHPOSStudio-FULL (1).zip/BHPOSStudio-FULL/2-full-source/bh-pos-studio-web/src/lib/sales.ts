import { db, type Product, type Sale, type SaleItem, type StockMovement } from './db'
import { enqueue, syncNow } from './sync'
import { round2, uuid } from './money'

export type PayMethod = 'cash' | 'card' | 'bank_transfer' | 'credit'
export interface CartLine { product: Product; qty: number; price: number }
export interface Discount { type: 'amount' | 'pct'; value: number }

export function totals(lines: CartLine[], d: Discount, taxPct: number) {
  const subtotal = round2(lines.reduce((s, l) => s + l.qty * l.price, 0))
  const raw = d.type === 'pct' ? (subtotal * Math.min(Math.max(d.value, 0), 100)) / 100 : Math.max(d.value, 0)
  const discount = round2(Math.min(raw, subtotal))
  const taxable = subtotal - discount
  const tax = round2((taxable * taxPct) / 100)
  return { subtotal, discount, tax, total: round2(taxable + tax) }
}

function deviceId() {
  let d = localStorage.getItem('bh-device')
  if (!d) { d = (Math.random().toString(36) + '0000').slice(2, 6).toUpperCase(); localStorage.setItem('bh-device', d) }
  return d
}
// Unique across devices (device code + counter) so offline sales never collide on the server's unique invoice number.
function nextInvoiceNo(now: Date) {
  const n = Number(localStorage.getItem('bh-inv-seq') || '0') + 1
  localStorage.setItem('bh-inv-seq', String(n))
  const ymd = now.toISOString().slice(2, 10).replace(/-/g, '')
  return `INV-${ymd}-${deviceId()}-${String(n).padStart(4, '0')}`
}

export interface SaleInput {
  lines: CartLine[]; discount: Discount; taxPct: number; method: PayMethod
  paid: number; customerId: string | null; cashierId: string
}

/** Saves the sale, stock movements and customer credit locally in ONE transaction, then queues them for upload.
 *  Works fully offline. Client-generated UUIDs make re-uploads idempotent. */
export async function createSale(inp: SaleInput): Promise<{ sale: Sale; items: SaleItem[] }> {
  if (!inp.lines.length) throw new Error('Cart is empty')
  const now = new Date()
  const iso = now.toISOString()
  const t = totals(inp.lines, inp.discount, inp.taxPct)
  const paid = round2(Math.min(Math.max(inp.paid, 0), t.total))
  const balance = round2(t.total - paid)
  if (balance > 0 && !inp.customerId) throw new Error('Select a customer for credit or part-payment')

  const result = await db.transaction('rw', [db.sales, db.saleItems, db.stockMovements, db.products, db.customers, db.outbox], async () => {
    for (const l of inp.lines) {
      const p = await db.products.get(l.product.id)
      if (!p || p.deleted_at) throw new Error(`"${l.product.name}" is no longer available`)
      if (l.qty > Number(p.stock_qty)) throw new Error(`Not enough stock for "${p.name}" (${p.stock_qty} left)`)
    }
    const sale: Sale = {
      id: uuid(), invoice_no: nextInvoiceNo(now), customer_id: inp.customerId, cashier_id: inp.cashierId,
      ...t, tax: t.tax, paid, balance, payment_method: inp.method, status: 'completed', device_id: deviceId(), created_at: iso
    }
    const items: SaleItem[] = inp.lines.map(l => ({
      id: uuid(), sale_id: sale.id, product_id: l.product.id, name: l.product.name, qty: l.qty,
      unit_price: l.price, unit_cost: Number(l.product.purchase_price), discount: 0, line_total: round2(l.qty * l.price)
    }))
    const moves: StockMovement[] = inp.lines.map(l => ({
      id: uuid(), product_id: l.product.id, kind: 'sale', qty: -l.qty, reason: 'Sale ' + sale.invoice_no, ref_id: sale.id, created_at: iso
    }))
    await db.sales.add(sale)
    await db.saleItems.bulkAdd(items)
    await db.stockMovements.bulkAdd(moves)
    for (const l of inp.lines) {
      await db.products.where('id').equals(l.product.id).modify(p => { p.stock_qty = round2(Number(p.stock_qty) - l.qty) })
    }
    if (inp.customerId && balance > 0) {
      await db.customers.where('id').equals(inp.customerId).modify(c => { c.credit_balance = round2(Number(c.credit_balance) + balance) })
    }
    // Upload order matters (foreign keys): sale → items → stock movements.
    await enqueue('sales', sale as unknown as Record<string, unknown>)
    await enqueue('sale_items', items as unknown as Record<string, unknown>[])
    await enqueue('stock_movements', moves as unknown as Record<string, unknown>[])
    return { sale, items }
  })
  void syncNow()
  return result
}
