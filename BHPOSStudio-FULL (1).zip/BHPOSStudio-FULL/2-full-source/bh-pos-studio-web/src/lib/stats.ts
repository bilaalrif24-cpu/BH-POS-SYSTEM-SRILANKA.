import { db, type Expense, type Sale, type SaleItem, type SaleReturn, type SaleReturnItem } from './db'
import { round2 } from './money'
import { addDays, ymd } from './dates'

export interface Data { sales: Sale[]; items: SaleItem[]; expenses: Expense[]; returns: SaleReturn[]; returnItems: SaleReturnItem[] }

export async function loadRange(from: Date, to: Date): Promise<Data> {
  const a = from.toISOString(), b = to.toISOString()
  const sales = await db.sales.where('created_at').between(a, b, true, false).toArray()
  const items = await db.saleItems.where('sale_id').anyOf(sales.map(s => s.id)).toArray()
  const returns = await db.saleReturns.where('created_at').between(a, b, true, false).toArray()
  const returnItems = await db.saleReturnItems.where('return_id').anyOf(returns.map(r => r.id)).toArray()
  const ya = ymd(from), yb = ymd(to)
  const expenses = await db.expenses.filter(e => !e.deleted_at && e.expense_date >= ya && e.expense_date < yb).toArray()
  return { sales, items, expenses, returns, returnItems }
}

const sum = (xs: number[]) => round2(xs.reduce((s, x) => s + Number(x), 0))
const restockedCost = (d: Data) => { const rs = new Set(d.returns.filter(r => r.restocked).map(r => r.id)); return sum(d.returnItems.filter(i => rs.has(i.return_id)).map(i => i.qty * i.unit_cost)) }

/** Everything is NET of returns, counted in the period the return happened. */
export function summarize(d: Data) {
  const net = round2(sum(d.sales.map(s => s.subtotal - s.discount)) - sum(d.returns.map(r => r.subtotal - r.discount)))
  const cogs = round2(sum(d.items.map(i => i.qty * i.unit_cost)) - restockedCost(d))
  const gross = round2(net - cogs)
  const expenses = sum(d.expenses.map(e => e.amount))
  return {
    count: d.sales.length, revenue: round2(sum(d.sales.map(s => s.total)) - sum(d.returns.map(r => r.total))), net,
    tax: round2(sum(d.sales.map(s => s.tax)) - sum(d.returns.map(r => r.tax))),
    discount: round2(sum(d.sales.map(s => s.discount)) - sum(d.returns.map(r => r.discount))),
    cogs, gross, expenses, profit: round2(gross - expenses), refunds: sum(d.returns.map(r => r.total)),
    collected: round2(sum(d.sales.map(s => s.paid)) - sum(d.returns.map(r => r.refunded))),
    credit: round2(sum(d.sales.map(s => s.balance)) - sum(d.returns.map(r => r.credit_reduced)))
  }
}

/** Daily net sales and gross profit for `days` days ending on `end`. */
export function dailySeries(d: Data, end: Date, days: number) {
  const cost = new Map<string, number>()
  d.items.forEach(i => cost.set(i.sale_id, (cost.get(i.sale_id) ?? 0) + i.qty * i.unit_cost))
  const by = new Map<string, { a: number; b: number }>()
  const add = (k: string, a: number, b: number) => { const c = by.get(k) ?? { a: 0, b: 0 }; by.set(k, { a: c.a + a, b: c.b + b }) }
  d.sales.forEach(s => { const net = s.subtotal - s.discount; add(ymd(new Date(s.created_at)), net, net - (cost.get(s.id) ?? 0)) })
  const rcost = new Map<string, number>()
  const rs = new Set(d.returns.filter(r => r.restocked).map(r => r.id))
  d.returnItems.forEach(i => { if (rs.has(i.return_id)) rcost.set(i.return_id, (rcost.get(i.return_id) ?? 0) + i.qty * i.unit_cost) })
  d.returns.forEach(r => { const net = r.subtotal - r.discount; add(ymd(new Date(r.created_at)), -net, -(net - (rcost.get(r.id) ?? 0))) })
  return Array.from({ length: days }, (_, i) => {
    const day = addDays(end, i - (days - 1)), v = by.get(ymd(day)) ?? { a: 0, b: 0 }
    return { label: String(day.getDate()), a: round2(Math.max(v.a, 0)), b: round2(v.b) }
  })
}
