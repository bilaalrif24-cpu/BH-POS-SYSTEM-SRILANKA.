import type { Table } from 'dexie'
import { db, type Payload } from './db'
import { supabase } from './supabase'

// Append-only tables: a retried upload must never overwrite or duplicate (insert ... on conflict do nothing).
const IMMUTABLE = new Set(['sales', 'sale_items', 'payments', 'purchases', 'purchase_items', 'stock_movements', 'sale_returns', 'sale_return_items', 'supplier_payments'])
const CONFLICT_KEY: Record<string, string> = { settings: 'key' }

let seq = 0
/** Add to the upload queue (no sync trigger — safe to call inside a Dexie transaction). Order is preserved. */
export async function enqueue(table: string, payload: Payload) {
  await db.outbox.put({ id: crypto.randomUUID(), table, payload, createdAt: Date.now() * 1000 + (seq++ % 1000), attempts: 0 })
}
export async function queueUpsert(table: string, payload: Payload) {
  await enqueue(table, payload)
  void syncNow()
}

export async function saveSetting(key: string, value: string) {
  const updatedAt = new Date().toISOString()
  await db.settings.put({ key, value, updatedAt })
  await queueUpsert('settings', { key, value, updated_at: updatedAt })
}

async function pushOutbox() {
  if (!supabase || !navigator.onLine) return
  const items = await db.outbox.orderBy('createdAt').toArray()
  for (const it of items) {
    const { error } = await supabase.from(it.table).upsert(it.payload, {
      onConflict: CONFLICT_KEY[it.table] ?? 'id',
      ignoreDuplicates: IMMUTABLE.has(it.table)
    })
    if (!error) { await db.outbox.delete(it.id); continue }
    await db.outbox.update(it.id, { attempts: it.attempts + 1, lastError: error.message })
    if (/fetch|network|timeout/i.test(error.message)) break // connection dropped: stop, retry later
  }
}

// Settings: last-write-wins by timestamp; never overwrite a change still waiting to upload.
async function pullSettings() {
  if (!supabase || !navigator.onLine) return
  const { data, error } = await supabase.from('settings').select('key,value,updated_at')
  if (error || !data) return
  const pending = new Set((await db.outbox.where('table').equals('settings').toArray()).map(i => String((i.payload as Record<string, unknown>).key)))
  for (const r of data) {
    if (pending.has(r.key)) continue
    const local = await db.settings.get(r.key)
    if (!local || Date.parse(local.updatedAt) < Date.parse(r.updated_at)) {
      await db.settings.put({ key: r.key, value: r.value, updatedAt: r.updated_at })
    }
  }
}

// Catalogue data. Stock and credit balances are computed by the server from uploaded movements/sales,
// so we only pull when nothing is waiting to upload (otherwise a stale server value could overwrite local stock).
async function pullCatalog() {
  if (!supabase || !navigator.onLine) return
  const waiting = await db.outbox.filter(i => i.attempts < 5).count()
  if (waiting > 0) return
  for (const name of ['categories', 'products', 'customers', 'suppliers', 'expenses'] as const) {
    const { data, error } = await supabase.from(name).select('*')
    if (error || !data) continue
    const table = db.table(name) as Table<Record<string, any>, string>
    for (const r of data) {
      const l = await table.get(r.id)
      const rv = Date.parse(r.updated_at ?? r.created_at)
      const lv = l ? Date.parse(l.updated_at ?? l.created_at) : -1
      if (!l || lv <= rv) await table.put(r)
    }
  }
}

// Append-only history from other devices (sales, purchases, payments, stock movements). Safe to pull any time:
// we only ADD rows we don't have. Windowed to the last 7 days before our newest row; "Re-download all" does everything.
const LEDGER = [
  { server: 'sales', local: 'sales', child: { server: 'sale_items', local: 'saleItems', fk: 'sale_id' } },
  { server: 'purchases', local: 'purchases', child: { server: 'purchase_items', local: 'purchaseItems', fk: 'purchase_id' } },
  { server: 'sale_returns', local: 'saleReturns', child: { server: 'sale_return_items', local: 'saleReturnItems', fk: 'return_id' } },
  { server: 'payments', local: 'payments' },
  { server: 'supplier_payments', local: 'supplierPayments' },
  { server: 'stock_movements', local: 'stockMovements' }
]
async function fetchSince(table: string, since: string) {
  const out: Record<string, any>[] = []
  for (let from = 0; ; from += 1000) {
    const { data, error } = await supabase!.from(table).select('*').gte('created_at', since).order('created_at').range(from, from + 999)
    if (error || !data) return out
    out.push(...data)
    if (data.length < 1000) return out
  }
}
async function pullLedger(full = false) {
  if (!supabase || !navigator.onLine) return
  for (const L of LEDGER) {
    const t = db.table(L.local) as Table<Record<string, any>, string>
    let since = '1970-01-01T00:00:00Z'
    if (!full) { const last = await t.orderBy('created_at').last(); if (last) since = new Date(Date.parse(last.created_at) - 7 * 864e5).toISOString() }
    const rows = await fetchSince(L.server, since)
    const have = await t.bulkGet(rows.map(r => r.id))
    const fresh = rows.filter((_, i) => !have[i])
    if (!fresh.length) continue
    await t.bulkPut(fresh)
    if (L.child) {
      const c = db.table(L.child.local) as Table<Record<string, any>, string>
      for (let i = 0; i < fresh.length; i += 100) {
        const { data } = await supabase.from(L.child.server).select('*').in(L.child.fk, fresh.slice(i, i + 100).map(r => r.id))
        if (data?.length) await c.bulkPut(data)
      }
    }
  }
}

let running = false
export async function syncNow() {
  if (running) return
  running = true
  try { await pushOutbox(); await pullSettings(); await pullCatalog(); await pullLedger() } catch { /* retried on next tick */ } finally { running = false }
}

export function startSync() {
  const run = () => { void syncNow() }
  run()
  window.addEventListener('online', run)
  const t = setInterval(run, 30000)
  return () => { window.removeEventListener('online', run); clearInterval(t) }
}

/** Settings → "Re-download all data": uploads anything pending, then fetches the full history from Supabase. */
export async function fullResync() {
  if (running) return
  running = true
  try { await pushOutbox(); await pullSettings(); await pullCatalog(); await pullLedger(true) } finally { running = false }
}
