import { useEffect, useState } from 'react'
import { SETTING_DEFAULTS, useSettingsMap } from '../lib/hooks'
import { saveSetting } from '../lib/sync'

const FIELDS: [string, string][] = [
  ['business_name', 'Business name'], ['business_address', 'Address'], ['business_phone', 'Phone number'],
  ['tax_percent', 'Tax % (0 for none)'], ['receipt_footer', 'Receipt footer message']
]

export default function BusinessSettings({ canEdit }: { canEdit: boolean }) {
  const s = useSettingsMap()
  const [form, setForm] = useState<Record<string, string>>({})
  const [ready, setReady] = useState(false)
  const [msg, setMsg] = useState('')
  useEffect(() => { if (s && !ready) { setForm(s); setReady(true) } }, [s, ready])
  const val = (k: string) => form[k] ?? SETTING_DEFAULTS[k] ?? ''

  async function save() {
    const tax = Number(val('tax_percent'))
    if (!val('business_name').trim()) { setMsg('Business name is required'); return }
    if (isNaN(tax) || tax < 0 || tax > 100) { setMsg('Tax must be between 0 and 100'); return }
    for (const k of [...FIELDS.map(f => f[0]), 'paper_width']) {
      const v = val(k).trim()
      if (v !== (s?.[k] ?? SETTING_DEFAULTS[k])) await saveSetting(k, v)
    }
    setMsg(navigator.onLine ? 'Saved' : 'Saved (will sync when online)')
  }

  return (
    <section className="glass space-y-3 p-5">
      <h3 className="font-semibold">Business &amp; receipts</h3>
      {FIELDS.map(([k, label]) => (
        <label key={k} className="block text-xs">{label}
          <input className="input mt-1" value={val(k)} disabled={!canEdit} onChange={e => { setForm({ ...form, [k]: e.target.value }); setMsg('') }} />
        </label>
      ))}
      <label className="block text-xs">Receipt paper
        <select className="input mt-1" value={val('paper_width')} disabled={!canEdit} onChange={e => { setForm({ ...form, paper_width: e.target.value }); setMsg('') }}>
          <option value="58">58 mm thermal</option><option value="80">80 mm thermal</option>
        </select>
      </label>
      {!canEdit && <p className="text-xs text-slate-500">Only an admin or manager can change these.</p>}
      <div className="flex items-center gap-3">
        <button className="btn-primary" disabled={!canEdit} onClick={() => void save()}>Save</button>
        {msg && <span className="text-sm text-emerald-500">{msg}</span>}
      </div>
    </section>
  )
}
