import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { MessageCircle, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { db, type Customer } from '../lib/db'
import { deleteCustomer, receivePayment, saveCustomerFull } from '../lib/ops'
import { fmt } from '../lib/money'
import Modal from '../components/Modal'

function CustomerForm({ c, onClose }: { c: Customer | null; onClose: () => void }) {
  const [f, setF] = useState({ name: c?.name ?? '', phone: c?.phone ?? '', email: c?.email ?? '', address: c?.address ?? '' })
  const [err, setErr] = useState('')
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })
  return (
    <Modal title={c ? 'Edit customer' : 'Add customer'} onClose={onClose}>
      <div className="space-y-3">
        <input className="input" placeholder="Name *" value={f.name} onChange={set('name')} />
        <input className="input" placeholder="Phone" inputMode="tel" value={f.phone} onChange={set('phone')} />
        <input className="input" placeholder="Email" type="email" value={f.email} onChange={set('email')} />
        <input className="input" placeholder="Address" value={f.address} onChange={set('address')} />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" onClick={async () => { const e = await saveCustomerFull({ id: c?.id, ...f }); if (e) setErr(e); else onClose() }}>Save</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </Modal>
  )
}

function CustomerDetail({ id, onClose }: { id: string; onClose: () => void }) {
  const c = useLiveQuery(() => db.customers.get(id), [id])
  const sales = useLiveQuery(() => db.sales.where('customer_id').equals(id).toArray(), [id]) ?? []
  const pays = useLiveQuery(() => db.payments.where('customer_id').equals(id).toArray(), [id]) ?? []
  const [amt, setAmt] = useState('')
  const [method, setMethod] = useState('cash')
  const [note, setNote] = useState('')
  const [err, setErr] = useState('')
  if (!c) return null
  const bal = Number(c.credit_balance)
  const history = [
    ...sales.map(s => ({ at: s.created_at, label: `Sale ${s.invoice_no}`, amount: s.total, sub: s.balance > 0 ? `on credit ${fmt(s.balance)}` : 'paid' })),
    ...pays.filter(p => !p.sale_id).map(p => ({ at: p.created_at, label: 'Payment received', amount: -p.amount, sub: p.method + (p.note ? ` · ${p.note}` : '') }))
  ].sort((a, b) => b.at.localeCompare(a.at))
  let phone = (c.phone ?? '').replace(/\D/g, '')
  if (phone.startsWith('0')) phone = '94' + phone.slice(1)
  const remind = `https://wa.me/${phone}?text=${encodeURIComponent(`Hello ${c.name}, a friendly reminder that your outstanding balance is ${fmt(bal)}. Thank you!`)}`

  return (
    <Modal title={c.name} onClose={onClose} wide>
      <div className="mb-3 text-sm text-slate-500 dark:text-slate-400">{[c.phone, c.email, c.address].filter(Boolean).join(' · ') || 'No contact details'}</div>
      <div className="glass mb-4 flex items-center justify-between p-3">
        <div><div className="text-xs text-slate-500">Outstanding balance</div><div className={`text-xl font-bold ${bal > 0 ? 'text-amber-600 dark:text-amber-400' : ''}`}>{fmt(bal)}</div></div>
        {bal > 0 && c.phone && <a className="btn-ghost" href={remind} target="_blank" rel="noreferrer"><MessageCircle size={16} />Remind</a>}
      </div>
      {bal > 0 && (
        <div className="mb-4 space-y-2">
          <h4 className="text-sm font-semibold">Receive payment</h4>
          <div className="flex gap-2">
            <input className="input" inputMode="decimal" placeholder={`Amount (max ${fmt(bal)})`} value={amt} onChange={e => setAmt(e.target.value)} />
            <select className="input !w-auto" value={method} onChange={e => setMethod(e.target.value)}><option value="cash">Cash</option><option value="card">Card</option><option value="bank_transfer">Bank</option></select>
          </div>
          <input className="input" placeholder="Note (optional)" value={note} onChange={e => setNote(e.target.value)} />
          {err && <p className="text-sm text-red-500">{err}</p>}
          <button className="btn-primary w-full" onClick={async () => { const e = await receivePayment(id, Number(amt), method, note); if (e) setErr(e); else { setErr(''); setAmt(''); setNote('') } }}>Record payment</button>
        </div>
      )}
      <h4 className="mb-1 text-sm font-semibold">History</h4>
      {history.length === 0 ? <p className="text-sm text-slate-500">No purchases yet.</p> : (
        <div className="max-h-64 divide-y divide-slate-300/50 overflow-y-auto text-sm dark:divide-white/10">
          {history.map((h, i) => (
            <div key={i} className="flex justify-between gap-2 py-2">
              <div><div className="font-medium">{h.label}</div><div className="text-xs text-slate-500 dark:text-slate-400">{new Date(h.at).toLocaleString('en-LK')} · {h.sub}</div></div>
              <div className={`font-semibold ${h.amount < 0 ? 'text-emerald-600' : ''}`}>{h.amount < 0 ? '-' : ''}{fmt(Math.abs(h.amount))}</div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  )
}

export default function Customers() {
  const customers = useLiveQuery(() => db.customers.filter(c => !c.deleted_at).toArray(), []) ?? []
  const [q, setQ] = useState('')
  const [form, setForm] = useState<Customer | 'new' | null>(null)
  const [view, setView] = useState<string | null>(null)
  const s = q.trim().toLowerCase()
  const shown = customers.filter(c => !s || c.name.toLowerCase().includes(s) || (c.phone ?? '').includes(s)).sort((a, b) => a.name.localeCompare(b.name))
  const owed = customers.reduce((t, c) => t + Math.max(0, Number(c.credit_balance)), 0)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="glass p-4"><div className="text-xs text-slate-500 dark:text-slate-400">Customers</div><div className="text-2xl font-bold">{customers.length}</div></div>
        <div className="glass p-4"><div className="text-xs text-slate-500 dark:text-slate-400">Total outstanding</div><div className="text-2xl font-bold text-amber-600 dark:text-amber-400">{fmt(owed)}</div></div>
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1"><Search size={16} className="absolute left-3 top-3.5 text-slate-400" /><input className="input !pl-9" placeholder="Search name or phone" value={q} onChange={e => setQ(e.target.value)} /></div>
        <button className="btn-primary" onClick={() => setForm('new')}><Plus size={16} />Add</button>
      </div>
      {shown.length === 0 ? (
        <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">{customers.length ? 'No matching customers.' : 'No customers yet. Add one here or while billing.'}</div>
      ) : shown.map(c => (
        <div key={c.id} className="glass flex items-center gap-2 p-3">
          <button className="min-w-0 flex-1 text-left" onClick={() => setView(c.id)}>
            <div className="truncate font-semibold">{c.name}</div>
            <div className="truncate text-xs text-slate-500 dark:text-slate-400">{c.phone || 'No phone'}</div>
          </button>
          <div className={`text-sm font-semibold ${Number(c.credit_balance) > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500'}`}>{fmt(c.credit_balance)}</div>
          <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10" onClick={() => setForm(c)} aria-label="Edit"><Pencil size={16} /></button>
          <button className="rounded-lg p-2 text-red-500 hover:bg-red-500/10" aria-label="Delete"
            onClick={() => { if (confirm(`Delete "${c.name}"?${Number(c.credit_balance) > 0 ? ' They still owe ' + fmt(c.credit_balance) + '.' : ''}`)) void deleteCustomer(c.id) }}><Trash2 size={16} /></button>
        </div>
      ))}
      {form && <CustomerForm c={form === 'new' ? null : form} onClose={() => setForm(null)} />}
      {view && <CustomerDetail id={view} onClose={() => setView(null)} />}
    </div>
  )
}
