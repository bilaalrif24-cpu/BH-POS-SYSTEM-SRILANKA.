import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../lib/db'
import { useAuth } from '../lib/auth'
import { useSetting } from '../lib/hooks'
import { MODULES } from '../lib/modules'
import { fmt } from '../lib/money'
import { addDays, startOfDay } from '../lib/dates'
import { dailySeries, loadRange, summarize } from '../lib/stats'
import BarChart from '../components/BarChart'
import BackupReminder from '../components/BackupReminder'

function Stat({ label, value, tone }: { label: string; value: string | number; tone?: string }) {
  return (
    <div className="glass p-4">
      <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</div>
      <div className={`mt-1 text-xl font-bold ${tone ?? ''}`}>{value}</div>
    </div>
  )
}

export default function Dashboard() {
  const { profile } = useAuth()
  const business = useSetting('business_name', 'My Business')
  const [days, setDays] = useState<7 | 30>(7)
  const today = startOfDay(new Date()).getTime()
  const isStaff = profile?.role !== 'cashier'

  const todaySum = useLiveQuery(async () => summarize(await loadRange(new Date(today), addDays(new Date(today), 1))), [today])
  const series = useLiveQuery(async () => dailySeries(await loadRange(addDays(new Date(today), 1 - days), addDays(new Date(today), 1)), new Date(today), days), [days, today])
  const revenue = useLiveQuery(async () => (await db.sales.toArray()).reduce((s, x) => s + Number(x.total), 0) - (await db.saleReturns.toArray()).reduce((s, r) => s + Number(r.total), 0), []) ?? 0
  const expenses = useLiveQuery(async () => (await db.expenses.filter(e => !e.deleted_at).toArray()).reduce((s, e) => s + Number(e.amount), 0), []) ?? 0
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at).count(), []) ?? 0
  const low = useLiveQuery(() => db.products.filter(p => !p.deleted_at && Number(p.stock_qty) <= Number(p.low_stock_level)).count(), []) ?? 0
  const customers = useLiveQuery(() => db.customers.filter(c => !c.deleted_at).count(), []) ?? 0
  const recent = useLiveQuery(() => db.sales.orderBy('created_at').reverse().limit(6).toArray(), []) ?? []
  const names = useLiveQuery(() => db.customers.toArray(), []) ?? []
  const shortcuts = MODULES.filter(m => profile && m.roles.includes(profile.role) && m.path !== 'dashboard')

  return (
    <div className="space-y-5">
      <div className="glass p-5">
        <h2 className="text-xl font-bold">Welcome, {profile?.fullName}</h2>
        <p className="text-sm capitalize text-slate-500 dark:text-slate-400">{profile?.role} · {business}</p>
      </div>
      {isStaff && <BackupReminder />}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Today's sales" value={fmt(todaySum?.revenue ?? 0)} />
        {isStaff && <Stat label="Today's profit" value={fmt(todaySum?.gross ?? 0)} tone="text-emerald-600 dark:text-emerald-400" />}
        {isStaff && <Stat label="Total revenue" value={fmt(revenue)} />}
        {isStaff && <Stat label="Total expenses" value={fmt(expenses)} />}
        <Stat label="Products" value={products} />
        <Stat label="Low-stock products" value={low} tone={low ? 'text-amber-600 dark:text-amber-400' : ''} />
        <Stat label="Customers" value={customers} />
        <Stat label="Sales today" value={todaySum?.count ?? 0} />
      </div>

      {isStaff && (
        <section className="glass p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-semibold">Sales analytics</h3>
            <div className="flex gap-1">{([7, 30] as const).map(d => <button key={d} className={`${days === d ? 'btn-primary' : 'btn-ghost'} !px-3 !py-1 text-xs`} onClick={() => setDays(d)}>{d === 7 ? 'Weekly' : 'Monthly'}</button>)}</div>
          </div>
          {series ? <BarChart data={series} /> : <p className="py-10 text-center text-sm">Loading…</p>}
        </section>
      )}

      <section className="glass p-4">
        <h3 className="mb-2 font-semibold">Recent transactions</h3>
        {recent.length === 0 ? <p className="py-4 text-center text-sm text-slate-500 dark:text-slate-400">No sales yet. Open POS Billing to make your first sale.</p> : (
          <div className="divide-y divide-slate-300/50 text-sm dark:divide-white/10">
            {recent.map(s => (
              <div key={s.id} className="flex justify-between gap-2 py-2">
                <div className="min-w-0"><div className="truncate font-medium">{s.invoice_no}</div><div className="truncate text-xs text-slate-500 dark:text-slate-400">{new Date(s.created_at).toLocaleString('en-LK')} · {names.find(c => c.id === s.customer_id)?.name ?? 'Walk-in'}</div></div>
                <div className="font-semibold">{fmt(s.total)}</div>
              </div>
            ))}
          </div>
        )}
      </section>

      <div>
        <h3 className="mb-2 font-semibold">Quick access</h3>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {shortcuts.map(m => (
            <Link key={m.path} to={'/' + m.path} className="glass flex flex-col gap-2 p-4 transition hover:-translate-y-0.5 hover:shadow-xl">
              <m.icon className="text-royal" size={22} /><span className="font-semibold">{m.title}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
