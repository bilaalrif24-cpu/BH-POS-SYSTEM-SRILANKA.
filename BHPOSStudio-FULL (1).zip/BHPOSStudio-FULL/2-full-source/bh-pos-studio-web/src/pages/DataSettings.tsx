import { useRef, useState } from 'react'
import { Download, Upload } from 'lucide-react'
import { exportBackup, restoreBackup } from '../lib/backup'

export default function DataSettings({ isAdmin }: { isAdmin: boolean }) {
  const file = useRef<HTMLInputElement>(null)
  const [msg, setMsg] = useState('')
  const [reupload, setReupload] = useState(false)
  const [last, setLast] = useState(localStorage.getItem('bh-last-backup'))

  async function onFile(f: File | undefined) {
    if (!f) return
    if (!confirm('Restore will REPLACE the data on this device with the backup. Continue?')) { if (file.current) file.current.value = ''; return }
    if (reupload && !confirm('Everything in the backup will also be uploaded to Supabase and may overwrite products/customers there. Continue?')) { if (file.current) file.current.value = ''; return }
    try {
      const c = await restoreBackup(await f.text(), reupload)
      setMsg(`Restored: ${Object.entries(c).filter(([, n]) => n).map(([k, n]) => `${n} ${k}`).join(', ') || 'empty backup'}.`)
    } catch (e) { setMsg(e instanceof Error ? e.message : 'Restore failed') }
    if (file.current) file.current.value = ''
  }

  return (
    <section className="glass space-y-3 p-5">
      <h3 className="font-semibold">Backup &amp; restore</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400">A backup is one file with all products, customers, sales, purchases, expenses and settings on this device. {last ? `Last backup: ${new Date(last).toLocaleString('en-LK')}.` : 'No backup made yet.'}</p>
      <div className="flex flex-wrap gap-2">
        <button className="btn-primary" onClick={async () => { await exportBackup(); setLast(localStorage.getItem('bh-last-backup')); setMsg('Backup downloaded.') }}><Download size={16} />Download backup</button>
        {isAdmin && <button className="btn-ghost" onClick={() => file.current?.click()}><Upload size={16} />Restore from file</button>}
        <input ref={file} type="file" accept="application/json,.json" hidden onChange={e => void onFile(e.target.files?.[0])} />
      </div>
      {isAdmin && <label className="flex items-start gap-2 text-sm"><input className="mt-1" type="checkbox" checked={reupload} onChange={e => setReupload(e.target.checked)} />Also upload everything to Supabase after restoring (use only for a new, empty database)</label>}
      {msg && <p className="text-sm text-emerald-600 dark:text-emerald-400">{msg}</p>}
    </section>
  )
}
