import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Download, Pencil, Plus, Trash2 } from 'lucide-react'
import { db, type Expense } from '../lib/db'
import { useAuth } from '../lib/auth'
import { deleteExpense, saveExpense } from '../lib/ops'
import { downloadCsv, toCsv } from '../lib/csv'
import { ymd } from '../lib/dates'
import { fmt, round2 } from '../lib/money'
import Modal from '../components/Modal'

function ExpenseForm({ e, cats, onClose }: { e: Expense | null; cats: string[]; onClose: () => void }) {
  const { profile } = useAuth()
  const [f, setF] = useState({ category: e?.category ?? '', description: e?.description ?? '', amount: e ? String(e.amount) : '', date: e?.expense_date ?? ymd(new Date()) })
  const [err, setErr] = useState('')
  const set = (k: keyof typeof f) => (ev: { target: { value: string } }) => setF({ ...f, [k]: ev.target.value })
  return (
    <Modal title={e ? 'Edit expense' : 'Add expense'} onClose={onClose}>
      <div className="space-y-3">
        <input className="input" list="exp-cats" placeholder="Category (rent, electricity, salaries…)" value={f.category} onChange={set('category')} />
        <datalist id="exp-cats">{cats.map(c => <option key={c} value={c} />)}</datalist>
        <input className="input" placeholder="Description (optional)" value={f.description} onChange={set('description')} />
        <div className="grid grid-cols-2 gap-2">
          <input className="input" inputMode="decimal" placeholder="Amount (LKR)" value={f.amount} onChange={set('amount')} />
          <input className="input" type="date" value={f.date} onChange={set('date')} />
        </div>
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" onClick={async () => { if (!profile) return; const r = await saveExpense({ id: e?.id, category: f.category, description: f.description, amount: Number(f.amount), date: f.date, userId: profile.id }); if (r) setErr(r); else onClose() }}>Save</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </Modal>
  )
}

export default function Expenses() {
  const all = useLiveQuery(() => db.expenses.filter(e => !e.deleted_at).toArray(), []) ?? []
  const [month, setMonth] = useState(ymd(new Date()).slice(0, 7))
  const [form, setForm] = useState<Expense | 'new' | null>(null)
  const rows = useMemo(() => all.filter(e => e.expense_date.startsWith(month)).sort((a, b) => b.expense_date.localeCompare(a.expense_date)), [all, month])
  const total = round2(rows.reduce((s, e) => s + Number(e.amount), 0))
  const byCat = useMemo(() => { const m = new Map<string, number>(); rows.forEach(e => m.set(e.category, (m.get(e.category) ?? 0) + Number(e.amount))); return [...m.entries()].sort((a, b) => b[1] - a[1]) }, [rows])
  const cats = useMemo(() => [...new Set(all.map(e => e.category))].sort(), [all])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input className="input !w-auto" type="month" value={month} onChange={e => e.target.value && setMonth(e.target.value)} />
        <div className="flex-1" />
        <button className="btn-ghost" onClick={() => downloadCsv(`expenses-${month}.csv`, toCsv([['date', 'category', 'description', 'amount'], ...rows.map(e => [e.expense_date, e.category, e.description, e.amount])]))}><Download size={16} />CSV</button>
        <button className="btn-primary" onClick={() => setForm('new')}><Plus size={16} />Add</button>
      </div>
      <div className="glass p-4">
        <div className="text-xs text-slate-500 dark:text-slate-400">Total this month</div>
        <div className="text-2xl font-bold">{fmt(total)}</div>
        {byCat.length > 0 && <div className="mt-3 space-y-1.5">{byCat.map(([c, v]) => (
          <div key={c} className="text-sm"><div className="flex justify-between"><span>{c}</span><span>{fmt(v)}</span></div>
            <div className="mt-0.5 h-1.5 rounded bg-slate-200 dark:bg-white/10"><div className="h-full rounded bg-royal" style={{ width: `${(v / total) * 100}%` }} /></div></div>
        ))}</div>}
      </div>
      {rows.length === 0 ? <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">No expenses recorded for this month.</div> : rows.map(e => (
        <div key={e.id} className="glass flex items-center gap-2 p-3">
          <div className="min-w-0 flex-1"><div className="truncate font-semibold">{e.category}</div><div className="truncate text-xs text-slate-500 dark:text-slate-400">{e.expense_date}{e.description ? ` · ${e.description}` : ''}</div></div>
          <div className="font-semibold">{fmt(e.amount)}</div>
          <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10" onClick={() => setForm(e)} aria-label="Edit"><Pencil size={16} /></button>
          <button className="rounded-lg p-2 text-red-500 hover:bg-red-500/10" aria-label="Delete" onClick={() => { if (confirm('Delete this expense?')) void deleteExpense(e.id) }}><Trash2 size={16} /></button>
        </div>
      ))}
      {form && <ExpenseForm e={form === 'new' ? null : form} cats={cats} onClose={() => setForm(null)} />}
    </div>
  )
}
