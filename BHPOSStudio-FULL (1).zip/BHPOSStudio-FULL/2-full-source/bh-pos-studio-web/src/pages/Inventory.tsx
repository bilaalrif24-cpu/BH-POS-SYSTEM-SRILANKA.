import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { AlertTriangle, ArrowDownToLine, ArrowUpFromLine, ClipboardCheck, Download, Search } from 'lucide-react'
import { db, type Product } from '../lib/db'
import { moveStock } from '../lib/ops'
import { downloadCsv, toCsv } from '../lib/csv'
import { fmt, round2 } from '../lib/money'
import Modal from '../components/Modal'

type Kind = 'in' | 'out' | 'adjustment'
const TITLE: Record<Kind, string> = { in: 'Stock in', out: 'Stock out', adjustment: 'Stock count (adjustment)' }

function StockModal({ p, kind, onClose }: { p: Product; kind: Kind; onClose: () => void }) {
  const [qty, setQty] = useState(kind === 'adjustment' ? String(p.stock_qty) : '')
  const [reason, setReason] = useState('')
  const [err, setErr] = useState('')
  return (
    <Modal title={`${TITLE[kind]} — ${p.name}`} onClose={onClose}>
      <div className="space-y-3">
        <p className="text-sm text-slate-500 dark:text-slate-400">Current stock: {p.stock_qty}</p>
        <label className="block text-xs">{kind === 'adjustment' ? 'Counted quantity' : 'Quantity'}<input className="input mt-1" inputMode="decimal" autoFocus value={qty} onChange={e => setQty(e.target.value)} /></label>
        <input className="input" placeholder={kind === 'out' ? 'Reason (damaged, expired, own use…)' : 'Reason / note (optional)'} value={reason} onChange={e => setReason(e.target.value)} />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" onClick={async () => { const e = await moveStock(p.id, kind, Number(qty), reason); if (e) setErr(e); else onClose() }}>Save</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </Modal>
  )
}

export default function Inventory() {
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at).toArray(), []) ?? []
  const moves = useLiveQuery(() => db.stockMovements.orderBy('created_at').reverse().limit(40).toArray(), []) ?? []
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'all' | 'low' | 'out'>('all')
  const [act, setAct] = useState<{ p: Product; kind: Kind } | null>(null)
  const nameOf = (id: string) => products.find(p => p.id === id)?.name ?? 'Deleted product'

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase()
    return products
      .filter(p => !s || p.name.toLowerCase().includes(s) || (p.sku ?? '').toLowerCase().includes(s) || (p.barcode ?? '').includes(s))
      .filter(p => filter === 'all' || (filter === 'out' ? Number(p.stock_qty) <= 0 : Number(p.stock_qty) <= Number(p.low_stock_level)))
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [products, q, filter])

  const units = round2(products.reduce((s, p) => s + Number(p.stock_qty), 0))
  const cost = round2(products.reduce((s, p) => s + Number(p.stock_qty) * Number(p.purchase_price), 0))
  const retail = round2(products.reduce((s, p) => s + Number(p.stock_qty) * Number(p.selling_price), 0))
  const lowCount = products.filter(p => Number(p.stock_qty) <= Number(p.low_stock_level)).length

  function exportCsv() {
    downloadCsv('inventory-valuation.csv', toCsv([['name', 'sku', 'barcode', 'stock', 'purchase_price', 'selling_price', 'value_at_cost', 'value_at_retail'],
      ...products.map(p => [p.name, p.sku, p.barcode, p.stock_qty, p.purchase_price, p.selling_price, round2(Number(p.stock_qty) * Number(p.purchase_price)), round2(Number(p.stock_qty) * Number(p.selling_price))])]))
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[['Products', String(products.length)], ['Units in stock', String(units)], ['Value at cost', fmt(cost)], ['Value at retail', fmt(retail)]].map(([l, v]) => (
          <div key={l} className="glass p-4"><div className="text-xs text-slate-500 dark:text-slate-400">{l}</div><div className="text-xl font-bold">{v}</div></div>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1"><Search size={16} className="absolute left-3 top-3.5 text-slate-400" /><input className="input !pl-9" placeholder="Search products" value={q} onChange={e => setQ(e.target.value)} /></div>
        {(['all', 'low', 'out'] as const).map(f => (
          <button key={f} className={filter === f ? 'btn-primary' : 'btn-ghost'} onClick={() => setFilter(f)}>{f === 'all' ? 'All' : f === 'low' ? `Low (${lowCount})` : 'Out'}</button>
        ))}
        <button className="btn-ghost" onClick={exportCsv}><Download size={16} />Valuation CSV</button>
      </div>

      {shown.length === 0 ? <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">{products.length ? 'Nothing matches this filter.' : 'No products yet. Add products first.'}</div> : shown.map(p => {
        const low = Number(p.stock_qty) <= Number(p.low_stock_level)
        return (
          <div key={p.id} className="glass flex flex-wrap items-center gap-2 p-3">
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{p.name}</div>
              <div className={`flex items-center gap-1 text-xs ${low ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}`}>{low && <AlertTriangle size={12} />}Stock {p.stock_qty} · alert at {p.low_stock_level} · value {fmt(Number(p.stock_qty) * Number(p.purchase_price))}</div>
            </div>
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => setAct({ p, kind: 'in' })}><ArrowDownToLine size={15} />In</button>
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => setAct({ p, kind: 'out' })}><ArrowUpFromLine size={15} />Out</button>
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => setAct({ p, kind: 'adjustment' })}><ClipboardCheck size={15} />Count</button>
          </div>
        )
      })}

      <section className="glass p-4">
        <h3 className="mb-2 font-semibold">Recent stock movements</h3>
        {moves.length === 0 ? <p className="text-sm text-slate-500 dark:text-slate-400">No movements yet.</p> : (
          <div className="divide-y divide-slate-300/50 text-sm dark:divide-white/10">
            {moves.map(m => (
              <div key={m.id} className="flex justify-between gap-2 py-2">
                <div className="min-w-0"><div className="truncate font-medium">{nameOf(m.product_id)}</div><div className="truncate text-xs text-slate-500 dark:text-slate-400">{m.kind} · {m.reason} · {new Date(m.created_at).toLocaleString('en-LK')}</div></div>
                <div className={`font-semibold ${Number(m.qty) < 0 ? 'text-red-500' : 'text-emerald-600'}`}>{Number(m.qty) > 0 ? '+' : ''}{m.qty}</div>
              </div>
            ))}
          </div>
        )}
      </section>
      {act && <StockModal p={act.p} kind={act.kind} onClose={() => setAct(null)} />}
    </div>
  )
}
