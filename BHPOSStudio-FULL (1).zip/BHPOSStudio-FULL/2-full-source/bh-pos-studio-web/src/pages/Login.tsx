import { useState, type FormEvent } from 'react'
import { useAuth } from '../lib/auth'
import { BrandHeader, Spinner } from '../components/Brand'

export default function Login() {
  const { signIn, signUp } = useAuth()
  const [signup, setSignup] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  async function submit(e: FormEvent) {
    e.preventDefault()
    setError(''); setInfo('')
    if (!email || !password || (signup && !name.trim())) { setError('Please fill in all fields'); return }
    if (!navigator.onLine) { setError('You are offline. The first sign-in on a device needs internet.'); return }
    setBusy(true)
    if (signup) {
      const r = await signUp(email, password, name)
      if (r.error) setError(r.error); else if (r.info) { setInfo(r.info); setSignup(false) }
    } else {
      const err = await signIn(email, password)
      if (err) setError(err)
    }
    setBusy(false)
  }

  return (
    <div className="app-bg flex min-h-full items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <BrandHeader />
        <form onSubmit={submit} className="glass space-y-3 p-5">
          <h2 className="text-lg font-bold">{signup ? 'Create account' : 'Sign in'}</h2>
          {signup && <input className="input" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} autoComplete="name" />}
          <input className="input" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
          <input className="input" type="password" placeholder="Password (min 6)" value={password} onChange={e => setPassword(e.target.value)} autoComplete={signup ? 'new-password' : 'current-password'} />
          {error && <p className="text-sm text-red-500">{error}</p>}
          {info && <p className="text-sm text-emerald-500">{info}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy ? <Spinner className="h-5 w-5" /> : signup ? 'CREATE ACCOUNT' : 'SIGN IN'}</button>
          <button type="button" className="w-full text-sm text-royal hover:underline" onClick={() => { setSignup(!signup); setError(''); setInfo('') }}>
            {signup ? 'Already have an account? Sign in' : 'New here? Create an account'}
          </button>
        </form>
      </div>
    </div>
  )
}
