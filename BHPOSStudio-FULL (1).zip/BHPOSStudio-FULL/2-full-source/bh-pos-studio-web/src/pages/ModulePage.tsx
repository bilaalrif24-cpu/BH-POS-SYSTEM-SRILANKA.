import { Check } from 'lucide-react'
import type { AppModule } from '../lib/modules'

/** Module whose data screens arrive in a later phase. Routing and role access are already live. */
export default function ModulePage({ m }: { m: AppModule }) {
  return (
    <div className="space-y-4">
      <div className="glass p-5">
        <m.icon className="text-royal" size={34} />
        <h2 className="mt-2 text-xl font-bold">{m.title}</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">{m.blurb}</p>
      </div>
      <div className="glass p-5">
        <h3 className="font-semibold">Arrives in {m.phase}</h3>
        <ul className="mt-2 space-y-1.5 text-sm">
          {m.features?.map(f => <li key={f} className="flex items-center gap-2"><Check size={16} className="text-royal" />{f}</li>)}
        </ul>
      </div>
    </div>
  )
}
