import { useState } from 'react'
import { useAuth } from '../lib/auth'
import { BrandHeader } from '../components/Brand'

export function Pending() {
  const { signOut, refresh } = useAuth()
  const [msg, setMsg] = useState('')
  return (
    <div className="app-bg flex min-h-full items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <BrandHeader />
        <div className="glass space-y-3 p-5 text-center">
          <h2 className="text-lg font-bold">Waiting for approval</h2>
          <p className="text-sm text-slate-600 dark:text-slate-300">Your account was created. An admin must activate it before you can use the POS.</p>
          {msg && <p className="text-sm text-amber-500">{msg}</p>}
          <button className="btn-primary w-full" onClick={async () => { await refresh(); setMsg('Still waiting for approval.') }}>Check again</button>
          <button className="btn-ghost w-full" onClick={() => void signOut()}>Sign out</button>
        </div>
      </div>
    </div>
  )
}

export function Setup() {
  return (
    <div className="app-bg flex min-h-full items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <BrandHeader />
        <div className="glass space-y-3 p-5 text-sm">
          <h2 className="text-lg font-bold">Connect Supabase</h2>
          <p>This site is missing its database settings. Add these environment variables, then rebuild or redeploy:</p>
          <pre className="overflow-x-auto rounded-xl bg-slate-900 p-3 text-xs text-slate-100">{'VITE_SUPABASE_URL\nVITE_SUPABASE_ANON_KEY'}</pre>
          <p>Locally: copy <code>.env.example</code> to <code>.env</code>. On Vercel/Netlify: Project Settings → Environment Variables. See README.md.</p>
        </div>
      </div>
    </div>
  )
}
