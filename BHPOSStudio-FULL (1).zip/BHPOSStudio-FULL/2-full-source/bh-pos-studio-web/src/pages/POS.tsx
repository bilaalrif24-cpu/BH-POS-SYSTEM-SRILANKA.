import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Banknote, Check, CreditCard, HandCoins, Landmark, Minus, Plus, ScanLine, Search, Trash2, UserPlus } from 'lucide-react'
import { db, type Product, type Sale, type SaleItem } from '../lib/db'
import { useAuth } from '../lib/auth'
import { useBiz } from '../lib/hooks'
import { createSale, totals, type CartLine, type PayMethod } from '../lib/sales'
import { saveCustomer } from '../lib/catalog'
import { fmt, round2 } from '../lib/money'
import BarcodeScanner from '../components/BarcodeScanner'
import InvoiceModal from '../components/InvoiceModal'

const METHODS: { id: PayMethod; label: string; icon: typeof Banknote }[] = [
  { id: 'cash', label: 'Cash', icon: Banknote }, { id: 'card', label: 'Card', icon: CreditCard },
  { id: 'bank_transfer', label: 'Bank', icon: Landmark }, { id: 'credit', label: 'Credit', icon: HandCoins }
]

export default function POS() {
  const { profile } = useAuth()
  const biz = useBiz()
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at && p.active).toArray(), []) ?? []
  const customers = useLiveQuery(() => db.customers.filter(c => !c.deleted_at).toArray(), []) ?? []
  const recent = useLiveQuery(() => db.sales.orderBy('created_at').reverse().limit(8).toArray(), []) ?? []

  const [q, setQ] = useState('')
  const [cart, setCart] = useState<CartLine[]>([])
  const [dType, setDType] = useState<'amount' | 'pct'>('amount')
  const [dVal, setDVal] = useState('')
  const [method, setMethod] = useState<PayMethod>('cash')
  const [paidStr, setPaidStr] = useState('')
  const [customerId, setCustomerId] = useState('')
  const [scan, setScan] = useState(false)
  const [tab, setTab] = useState<'items' | 'cart'>('items')
  const [done, setDone] = useState<{ sale: Sale; items: SaleItem[] } | null>(null)
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  const [addCust, setAddCust] = useState(false)
  const [cName, setCName] = useState('')
  const [cPhone, setCPhone] = useState('')

  const t = totals(cart, { type: dType, value: Number(dVal) || 0 }, biz.taxPct)
  const paid = paidStr === '' ? (method === 'credit' ? 0 : t.total) : Number(paidStr) || 0
  const effPaid = Math.min(paid, t.total)
  const balance = round2(t.total - effPaid)
  const change = method === 'cash' ? round2(Math.max(paid - t.total, 0)) : 0
  const count = cart.reduce((s, l) => s + l.qty, 0)

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase()
    const list = s ? products.filter(p => p.name.toLowerCase().includes(s) || (p.sku ?? '').toLowerCase().includes(s) || p.barcode === q.trim()) : products
    return list.sort((a, b) => a.name.localeCompare(b.name)).slice(0, 60)
  }, [products, q])

  function add(p: Product) {
    setMsg('')
    const stock = Number(p.stock_qty)
    const i = cart.findIndex(l => l.product.id === p.id)
    const cur = i >= 0 ? cart[i].qty : 0
    if (cur + 1 > stock) { setMsg(`Only ${stock} of "${p.name}" in stock`); return }
    setCart(i >= 0 ? cart.map((l, j) => (j === i ? { ...l, qty: l.qty + 1 } : l)) : [...cart, { product: p, qty: 1, price: Number(p.selling_price) }])
  }
  function onCode(code: string) {
    const c = code.trim()
    const p = products.find(x => x.barcode === c || x.sku === c)
    if (p) { add(p); setQ('') } else setMsg(`No product with code ${c}`)
  }
  function setQty(i: number, n: number) {
    const stock = Number(cart[i].product.stock_qty)
    if (n <= 0) { setCart(cart.filter((_, j) => j !== i)); return }
    if (n > stock) { setMsg(`Only ${stock} of "${cart[i].product.name}" in stock`); n = stock }
    setCart(cart.map((l, j) => (j === i ? { ...l, qty: n } : l)))
  }

  async function newCustomer() {
    const r = await saveCustomer(cName, cPhone)
    if (typeof r === 'string') { setMsg(r); return }
    setCustomerId(r.id); setAddCust(false); setCName(''); setCPhone('')
  }

  async function charge() {
    setMsg('')
    if (!cart.length || !profile) return
    if (balance > 0.004 && !customerId) { setMsg('Select a customer for credit or part-payment'); return }
    setBusy(true)
    try {
      const r = await createSale({ lines: cart, discount: { type: dType, value: Number(dVal) || 0 }, taxPct: biz.taxPct, method, paid: effPaid, customerId: customerId || null, cashierId: profile.id })
      setDone(r); setCart([]); setDVal(''); setPaidStr(''); setMethod('cash'); setCustomerId(''); setTab('items')
    } catch (e) { setMsg(e instanceof Error ? e.message : 'Could not save the sale') }
    setBusy(false)
  }

  const buyer = (id: string | null) => { const c = customers.find(x => x.id === id); return c ? { name: c.name, phone: c.phone } : null }
  async function openRecent(s: Sale) { setDone({ sale: s, items: await db.saleItems.where('sale_id').equals(s.id).toArray() }) }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 lg:hidden">
        <button className={`${tab === 'items' ? 'btn-primary' : 'btn-ghost'} flex-1`} onClick={() => setTab('items')}>Products</button>
        <button className={`${tab === 'cart' ? 'btn-primary' : 'btn-ghost'} flex-1`} onClick={() => setTab('cart')}>Cart ({count}) · {fmt(t.total)}</button>
      </div>
      {msg && <p className="glass p-3 text-sm text-amber-600 dark:text-amber-400">{msg}</p>}

      <div className="grid gap-4 lg:grid-cols-[1fr_24rem]">
        <section className={`space-y-3 ${tab === 'items' ? '' : 'hidden lg:block'}`}>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-3.5 text-slate-400" />
              <input className="input !pl-9" placeholder="Search or scan barcode, press Enter" value={q} autoFocus
                onChange={e => setQ(e.target.value)}
                onKeyDown={e => {
                  if (e.key !== 'Enter') return
                  const c = q.trim(); const exact = products.find(x => x.barcode === c || x.sku === c)
                  if (exact) { add(exact); setQ('') } else if (shown.length === 1) { add(shown[0]); setQ('') }
                }} />
            </div>
            <button className="btn-ghost" onClick={() => setScan(true)} aria-label="Scan with camera"><ScanLine size={18} /></button>
          </div>
          {shown.length === 0 ? (
            <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {products.length ? 'No matching products.' : 'No products yet. Add some in the Products module (admin/manager).'}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {shown.map(p => {
                const out = Number(p.stock_qty) <= 0
                return (
                  <button key={p.id} disabled={out} onClick={() => add(p)} className="glass p-3 text-left transition hover:-translate-y-0.5 disabled:opacity-50">
                    {p.image_url && <img src={p.image_url} alt="" className="mb-1 h-16 w-full rounded-lg object-cover" />}
                    <div className="line-clamp-2 text-sm font-semibold">{p.name}</div>
                    <div className="mt-1 text-sm text-royal">{fmt(p.selling_price)}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{out ? 'Out of stock' : `Stock ${p.stock_qty}`}</div>
                  </button>
                )
              })}
            </div>
          )}
        </section>

        <section className={`glass space-y-3 p-4 ${tab === 'cart' ? '' : 'hidden lg:block'}`}>
          <h3 className="font-semibold">Cart</h3>
          {cart.length === 0 ? <p className="py-4 text-center text-sm text-slate-500 dark:text-slate-400">Cart is empty. Tap a product or scan a barcode.</p> : (
            <div className="space-y-2">
              {cart.map((l, i) => (
                <div key={l.product.id} className="flex items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{l.product.name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{fmt(l.price)} each</div>
                  </div>
                  <button className="rounded-lg border border-slate-300 p-1.5 dark:border-white/15" onClick={() => setQty(i, l.qty - 1)} aria-label="Decrease"><Minus size={14} /></button>
                  <input className="input !w-14 !px-1 !py-1 text-center" inputMode="decimal" value={l.qty} onChange={e => setQty(i, Number(e.target.value) || 0)} />
                  <button className="rounded-lg border border-slate-300 p-1.5 dark:border-white/15" onClick={() => setQty(i, l.qty + 1)} aria-label="Increase"><Plus size={14} /></button>
                  <div className="w-24 text-right text-sm font-semibold">{fmt(l.qty * l.price)}</div>
                  <button className="text-red-500" onClick={() => setCart(cart.filter((_, j) => j !== i))} aria-label="Remove"><Trash2 size={16} /></button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <select className="input !w-auto" value={dType} onChange={e => setDType(e.target.value as 'amount' | 'pct')}><option value="amount">Discount LKR</option><option value="pct">Discount %</option></select>
            <input className="input" inputMode="decimal" placeholder="0" value={dVal} onChange={e => setDVal(e.target.value)} />
          </div>

          <div className="space-y-1 border-t border-slate-300/60 pt-3 text-sm dark:border-white/10">
            <div className="flex justify-between"><span>Subtotal</span><span>{fmt(t.subtotal)}</span></div>
            {t.discount > 0 && <div className="flex justify-between"><span>Discount</span><span>-{fmt(t.discount)}</span></div>}
            {t.tax > 0 && <div className="flex justify-between"><span>Tax ({biz.taxPct}%)</span><span>{fmt(t.tax)}</span></div>}
            <div className="flex justify-between text-lg font-bold"><span>Total</span><span>{fmt(t.total)}</span></div>
          </div>

          <div className="grid grid-cols-4 gap-1.5">
            {METHODS.map(m => (
              <button key={m.id} onClick={() => { setMethod(m.id); setPaidStr('') }} className={`${method === m.id ? 'btn-primary' : 'btn-ghost'} flex-col !gap-1 !px-1 !py-2 text-xs`}><m.icon size={18} />{m.label}</button>
            ))}
          </div>
          <input className="input" inputMode="decimal" placeholder={`Amount received (${fmt(paid)})`} value={paidStr} onChange={e => setPaidStr(e.target.value)} />
          {change > 0 && <div className="flex justify-between text-sm font-semibold text-emerald-600 dark:text-emerald-400"><span>Change</span><span>{fmt(change)}</span></div>}
          {balance > 0 && cart.length > 0 && <div className="flex justify-between text-sm font-semibold text-amber-600 dark:text-amber-400"><span>On credit</span><span>{fmt(balance)}</span></div>}

          <div className="space-y-2">
            <div className="flex gap-2">
              <select className="input" value={customerId} onChange={e => setCustomerId(e.target.value)}>
                <option value="">Walk-in customer</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name}{c.phone ? ` · ${c.phone}` : ''}</option>)}
              </select>
              <button className="btn-ghost !px-3" onClick={() => setAddCust(!addCust)} aria-label="New customer"><UserPlus size={18} /></button>
            </div>
            {addCust && (
              <div className="flex gap-2">
                <input className="input" placeholder="Name" value={cName} onChange={e => setCName(e.target.value)} />
                <input className="input" placeholder="Phone" inputMode="tel" value={cPhone} onChange={e => setCPhone(e.target.value)} />
                <button className="btn-primary !px-3" onClick={() => void newCustomer()} aria-label="Save customer"><Check size={18} /></button>
              </div>
            )}
          </div>

          <button className="btn-primary w-full !py-3 text-base" disabled={!cart.length || busy} onClick={() => void charge()}>
            {busy ? 'Saving…' : `CHARGE ${fmt(t.total)}`}
          </button>
        </section>
      </div>

      <section className="glass p-4">
        <h3 className="mb-2 font-semibold">Recent sales on this device</h3>
        {recent.length === 0 ? <p className="text-sm text-slate-500 dark:text-slate-400">No sales yet.</p> : (
          <div className="divide-y divide-slate-300/50 dark:divide-white/10">
            {recent.map(s => (
              <button key={s.id} className="flex w-full items-center justify-between py-2 text-left text-sm" onClick={() => void openRecent(s)}>
                <span><span className="font-medium">{s.invoice_no}</span><span className="block text-xs text-slate-500 dark:text-slate-400">{new Date(s.created_at).toLocaleString('en-LK')}</span></span>
                <span className="font-semibold">{fmt(s.total)}</span>
              </button>
            ))}
          </div>
        )}
      </section>

      {scan && <BarcodeScanner onDetect={onCode} onClose={() => setScan(false)} />}
      {done && <InvoiceModal sale={done.sale} items={done.items} buyer={buyer(done.sale.customer_id)} onClose={() => setDone(null)} />}
    </div>
  )
}
