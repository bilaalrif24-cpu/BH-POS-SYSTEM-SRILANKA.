import { useState } from 'react'
import { Bluetooth } from 'lucide-react'
import { useBiz } from '../lib/hooks'
import { btConnected, btName, btSupported, connectPrinter, disconnectPrinter, sendToPrinter } from '../lib/bluetooth'
import { getPrintMode, setPrintMode, testBytes, type PrintMode } from '../lib/printjob'

export default function PrinterSettings() {
  const biz = useBiz()
  const [name, setName] = useState(btName())
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  const [mode, setMode] = useState<PrintMode>(getPrintMode())
  const run = async (fn: () => Promise<void>) => { setBusy(true); setMsg(''); try { await fn() } catch (e) { setMsg(e instanceof Error ? e.message : 'Something went wrong') } setBusy(false); setName(btName()) }

  return (
    <section className="glass space-y-3 p-5">
      <h3 className="flex items-center gap-2 font-semibold"><Bluetooth size={18} />Receipt printer (Bluetooth)</h3>
      {!btSupported() ? (
        <p className="text-sm text-slate-600 dark:text-slate-300">Bluetooth printing needs Chrome on Android or Windows. Receipts can still be printed with the Print button (browser print dialog).</p>
      ) : (
        <>
          <p className="text-sm text-slate-500 dark:text-slate-400">{btConnected() ? `Connected: ${name}` : name ? `Last used: ${name} (not connected)` : 'No printer connected.'} Paper width ({biz.paper} mm) is set under Business &amp; receipts.</p>
          <div className="flex flex-wrap gap-2">
            <button className="btn-primary" disabled={busy} onClick={() => void run(connectPrinter)}>{btConnected() ? 'Choose another printer' : 'Connect printer'}</button>
            <button className="btn-ghost" disabled={busy} onClick={() => void run(async () => { await sendToPrinter(testBytes(biz)); setMsg('Test page sent.') })}>Test print</button>
            {btConnected() && <button className="btn-ghost" onClick={() => { disconnectPrinter(); setName(btName()); setMsg('Disconnected.') }}>Disconnect</button>}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">Turn the printer on and pair it from this screen. Works with BLE (Bluetooth 4+) ESC/POS printers. </p>
          <label className="block text-xs">Print mode
            <select className="input mt-1" value={mode} onChange={e => { const m = e.target.value as PrintMode; setPrintMode(m); setMode(m) }}>
              <option value="text">Text — fast, English letters and numbers only</option>
              <option value="image">Image — any language incl. Sinhala &amp; Tamil (slower)</option>
            </select></label>
        </>
      )}
      {msg && <p className="text-sm text-amber-600 dark:text-amber-400">{msg}</p>}
    </section>
  )
}
