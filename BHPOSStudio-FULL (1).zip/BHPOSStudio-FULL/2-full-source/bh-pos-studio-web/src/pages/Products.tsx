import { useMemo, useRef, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { AlertTriangle, Download, Pencil, Plus, ScanLine, Search, Trash2, Upload } from 'lucide-react'
import { db, type Product } from '../lib/db'
import { createCategory, deleteProduct, importProducts, saveProduct } from '../lib/catalog'
import { downloadCsv, parseCsv, toCsv } from '../lib/csv'
import { fmt } from '../lib/money'
import { resizeImage } from '../lib/image'
import Modal from '../components/Modal'
import BarcodeScanner from '../components/BarcodeScanner'

function ProductForm({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const cats = useLiveQuery(() => db.categories.orderBy('name').toArray(), []) ?? []
  const [f, setF] = useState({
    name: product?.name ?? '', sku: product?.sku ?? '', barcode: product?.barcode ?? '', categoryId: product?.category_id ?? '',
    purchase: String(product?.purchase_price ?? ''), selling: String(product?.selling_price ?? ''), low: String(product?.low_stock_level ?? 5),
    stock: '', reason: ''
  })
  const [newCat, setNewCat] = useState('')
  const [scan, setScan] = useState(false)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [image, setImage] = useState<string | null | undefined>(undefined)
  const shownImage = image === undefined ? product?.image_url ?? null : image
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })

  async function submit() {
    setErr(''); setBusy(true)
    const categoryId = newCat.trim() ? await createCategory(newCat) : f.categoryId || null
    const stock = Number(f.stock) || 0
    const e = await saveProduct({
      id: product?.id, name: f.name, sku: f.sku, barcode: f.barcode, categoryId,
      purchase: Number(f.purchase) || 0, selling: Number(f.selling) || 0, low: Number(f.low) || 0,
      image, openingStock: product ? undefined : stock, adjust: product ? stock : undefined, adjustReason: f.reason
    })
    setBusy(false)
    if (e) setErr(e); else onClose()
  }

  return (
    <Modal title={product ? 'Edit product' : 'Add product'} onClose={onClose}>
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          {shownImage ? <img src={shownImage} alt="" className="h-16 w-16 rounded-xl object-cover" /> : <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-slate-200/60 text-xs text-slate-500 dark:bg-white/10">No photo</div>}
          <label className="btn-ghost cursor-pointer">Choose photo<input type="file" accept="image/*" hidden onChange={async e => { const f = e.target.files?.[0]; if (f) { try { setImage(await resizeImage(f)) } catch { setErr('Could not read that image') } } }} /></label>
          {shownImage && <button type="button" className="text-xs text-red-500" onClick={() => setImage(null)}>Remove</button>}
        </div>
        <input className="input" placeholder="Product name *" value={f.name} onChange={set('name')} />
        <div className="grid grid-cols-2 gap-2">
          <input className="input" placeholder="SKU" value={f.sku} onChange={set('sku')} />
          <div className="flex gap-1">
            <input className="input" placeholder="Barcode" value={f.barcode} onChange={set('barcode')} />
            <button type="button" className="btn-ghost !px-3" onClick={() => setScan(true)} aria-label="Scan barcode"><ScanLine size={18} /></button>
          </div>
        </div>
        <button type="button" className="text-xs text-royal hover:underline" onClick={() => setF({ ...f, barcode: 'BH' + String(Date.now()).slice(-10) })}>Generate a barcode</button>
        <div className="grid grid-cols-2 gap-2">
          <select className="input" value={f.categoryId} onChange={set('categoryId')} disabled={!!newCat.trim()}>
            <option value="">No category</option>
            {cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input className="input" placeholder="…or new category" value={newCat} onChange={e => setNewCat(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-xs">Purchase price (LKR)<input className="input mt-1" inputMode="decimal" value={f.purchase} onChange={set('purchase')} /></label>
          <label className="text-xs">Selling price (LKR)<input className="input mt-1" inputMode="decimal" value={f.selling} onChange={set('selling')} /></label>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-xs">Low-stock level<input className="input mt-1" inputMode="decimal" value={f.low} onChange={set('low')} /></label>
          <label className="text-xs">{product ? `Adjust stock (now ${product.stock_qty}) +/-` : 'Opening stock'}
            <input className="input mt-1" inputMode="decimal" value={f.stock} onChange={set('stock')} placeholder={product ? 'e.g. -2 or 10' : '0'} /></label>
        </div>
        {product && f.stock && <input className="input" placeholder="Reason for adjustment" value={f.reason} onChange={set('reason')} />}
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" disabled={busy} onClick={() => void submit()}>Save</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
      {scan && <BarcodeScanner onDetect={c => { setF(x => ({ ...x, barcode: c })); setScan(false) }} onClose={() => setScan(false)} />}
    </Modal>
  )
}

export default function Products() {
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at).toArray(), []) ?? []
  const cats = useLiveQuery(() => db.categories.toArray(), []) ?? []
  const [q, setQ] = useState('')
  const [editing, setEditing] = useState<Product | 'new' | null>(null)
  const [note, setNote] = useState('')
  const file = useRef<HTMLInputElement>(null)
  const catName = (id: string | null) => cats.find(c => c.id === id)?.name ?? ''

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase()
    return products.filter(p => !s || p.name.toLowerCase().includes(s) || (p.sku ?? '').toLowerCase().includes(s) || (p.barcode ?? '').toLowerCase().includes(s))
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [products, q])

  function exportCsv() {
    const rows = [['name', 'sku', 'barcode', 'category', 'purchase_price', 'selling_price', 'stock_qty', 'low_stock_level'],
      ...products.map(p => [p.name, p.sku, p.barcode, catName(p.category_id), p.purchase_price, p.selling_price, p.stock_qty, p.low_stock_level])]
    downloadCsv('products.csv', toCsv(rows))
  }

  async function onImport(f: File | undefined) {
    if (!f) return
    const r = await importProducts(parseCsv(await f.text()))
    setNote(`Imported: ${r.created} new, ${r.updated} updated${r.errors.length ? `, ${r.errors.length} skipped — ${r.errors.slice(0, 3).join('; ')}` : ''}`)
    if (file.current) file.current.value = ''
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1">
          <Search size={16} className="absolute left-3 top-3.5 text-slate-400" />
          <input className="input !pl-9" placeholder="Search name, SKU or barcode" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <button className="btn-primary" onClick={() => setEditing('new')}><Plus size={16} />Add</button>
        <button className="btn-ghost" onClick={() => file.current?.click()}><Upload size={16} />Import</button>
        <button className="btn-ghost" onClick={exportCsv}><Download size={16} />Export</button>
        <input ref={file} type="file" accept=".csv,text/csv" hidden onChange={e => void onImport(e.target.files?.[0])} />
      </div>
      {note && <p className="glass p-3 text-sm">{note}</p>}
      <p className="text-xs text-slate-500 dark:text-slate-400">CSV columns: name, sku, barcode, category, purchase_price, selling_price, stock_qty, low_stock_level. Stock in a CSV applies to new products only.</p>

      {shown.length === 0 ? (
        <div className="glass p-8 text-center">
          <div className="font-semibold">{products.length ? 'No matching products' : 'No products yet'}</div>
          <p className="text-sm text-slate-500 dark:text-slate-400">{products.length ? 'Try a different search.' : 'Add your first product or import a CSV.'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {shown.map(p => {
            const low = Number(p.stock_qty) <= Number(p.low_stock_level)
            return (
              <div key={p.id} className="glass flex items-center gap-3 p-3">
                {p.image_url && <img src={p.image_url} alt="" className="h-11 w-11 rounded-lg object-cover" />}
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold">{p.name}</div>
                  <div className="truncate text-xs text-slate-500 dark:text-slate-400">
                    {[catName(p.category_id), p.sku, p.barcode].filter(Boolean).join(' · ') || '—'}
                  </div>
                </div>
                <div className="text-right text-sm">
                  <div className="font-semibold">{fmt(p.selling_price)}</div>
                  <div className={`flex items-center justify-end gap-1 text-xs ${low ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}`}>
                    {low && <AlertTriangle size={12} />}Stock {p.stock_qty}
                  </div>
                </div>
                <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10" onClick={() => setEditing(p)} aria-label="Edit"><Pencil size={16} /></button>
                <button className="rounded-lg p-2 text-red-500 hover:bg-red-500/10" aria-label="Delete"
                  onClick={() => { if (confirm(`Delete "${p.name}"? Past sales keep their records.`)) void deleteProduct(p.id) }}><Trash2 size={16} /></button>
              </div>
            )
          })}
        </div>
      )}
      {editing && <ProductForm product={editing === 'new' ? null : editing} onClose={() => setEditing(null)} />}
    </div>
  )
}
