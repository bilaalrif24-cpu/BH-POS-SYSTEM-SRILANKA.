import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Plus, Trash2 } from 'lucide-react'
import { db, type Product, type Purchase, type Supplier } from '../lib/db'
import { useAuth } from '../lib/auth'
import { createPurchase, paySupplier, saveSupplier, type PurchaseLine } from '../lib/ops'
import { fmt, round2 } from '../lib/money'
import Modal from '../components/Modal'

function SupplierForm({ s, onClose, onSaved }: { s: Supplier | null; onClose: () => void; onSaved?: (s: Supplier) => void }) {
  const [f, setF] = useState({ name: s?.name ?? '', phone: s?.phone ?? '', address: s?.address ?? '' })
  const [err, setErr] = useState('')
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })
  return (
    <Modal title={s ? 'Edit supplier' : 'Add supplier'} onClose={onClose}>
      <div className="space-y-3">
        <input className="input" placeholder="Supplier name *" value={f.name} onChange={set('name')} />
        <input className="input" placeholder="Phone" inputMode="tel" value={f.phone} onChange={set('phone')} />
        <input className="input" placeholder="Address" value={f.address} onChange={set('address')} />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" onClick={async () => { const r = await saveSupplier({ id: s?.id, ...f }); if (typeof r === 'string') setErr(r); else { onSaved?.(r); onClose() } }}>Save</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </Modal>
  )
}

interface FormLine { product: Product; qty: string; cost: string }

function PurchaseForm({ onClose }: { onClose: () => void }) {
  const { profile } = useAuth()
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at).toArray(), []) ?? []
  const suppliers = useLiveQuery(() => db.suppliers.filter(s => !s.deleted_at).toArray(), []) ?? []
  const [supplierId, setSupplierId] = useState('')
  const [reference, setReference] = useState('')
  const [lines, setLines] = useState<FormLine[]>([])
  const [pq, setPq] = useState('')
  const [paidStr, setPaidStr] = useState('')
  const [updateCost, setUpdateCost] = useState(true)
  const [addSup, setAddSup] = useState(false)
  const [err, setErr] = useState('')

  const total = round2(lines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.cost) || 0), 0))
  const paid = paidStr === '' ? total : Number(paidStr) || 0
  const s = pq.trim().toLowerCase()
  const matches = s ? products.filter(p => p.name.toLowerCase().includes(s) || (p.sku ?? '').toLowerCase().includes(s) || (p.barcode ?? '') === pq.trim()).slice(0, 6) : []
  const addLine = (p: Product) => { if (!lines.some(l => l.product.id === p.id)) setLines([...lines, { product: p, qty: '1', cost: String(p.purchase_price) }]); setPq('') }
  const upd = (i: number, k: 'qty' | 'cost', v: string) => setLines(lines.map((l, j) => (j === i ? { ...l, [k]: v } : l)))

  async function save() {
    if (!profile) return
    const pl: PurchaseLine[] = lines.map(l => ({ product: l.product, qty: Number(l.qty) || 0, cost: Number(l.cost) || 0 }))
    const e = await createPurchase({ supplierId: supplierId || null, reference, lines: pl, paid, updateCost, userId: profile.id })
    if (e) setErr(e); else onClose()
  }

  return (
    <Modal title="New purchase" onClose={onClose} wide>
      <div className="space-y-3">
        <div className="flex gap-2">
          <select className="input" value={supplierId} onChange={e => setSupplierId(e.target.value)}>
            <option value="">No supplier</option>{suppliers.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
          <button className="btn-ghost !px-3" onClick={() => setAddSup(true)} aria-label="Add supplier"><Plus size={18} /></button>
        </div>
        <input className="input" placeholder="Reference / supplier invoice no. (optional)" value={reference} onChange={e => setReference(e.target.value)} />
        <div>
          <input className="input" placeholder="Search product to add (name, SKU or barcode)" value={pq} onChange={e => setPq(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && matches.length) addLine(matches[0]) }} />
          {matches.length > 0 && <div className="glass mt-1 divide-y divide-slate-300/50 dark:divide-white/10">{matches.map(p => (
            <button key={p.id} className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-200/60 dark:hover:bg-white/10" onClick={() => addLine(p)}>{p.name} <span className="text-xs text-slate-500">· stock {p.stock_qty}</span></button>
          ))}</div>}
        </div>
        {lines.length === 0 ? <p className="py-3 text-center text-sm text-slate-500">Search above to add items.</p> : (
          <div className="space-y-2">
            {lines.map((l, i) => (
              <div key={l.product.id} className="flex items-center gap-2">
                <div className="min-w-0 flex-1 truncate text-sm font-medium">{l.product.name}</div>
                <input className="input !w-16 !px-2 !py-1.5" inputMode="decimal" value={l.qty} onChange={e => upd(i, 'qty', e.target.value)} aria-label="Quantity" />
                <input className="input !w-24 !px-2 !py-1.5" inputMode="decimal" value={l.cost} onChange={e => upd(i, 'cost', e.target.value)} aria-label="Unit cost" />
                <button className="text-red-500" onClick={() => setLines(lines.filter((_, j) => j !== i))} aria-label="Remove"><Trash2 size={16} /></button>
              </div>
            ))}
            <p className="text-xs text-slate-500">Quantity · unit cost (LKR)</p>
          </div>
        )}
        <div className="flex justify-between text-lg font-bold"><span>Total</span><span>{fmt(total)}</span></div>
        <input className="input" inputMode="decimal" placeholder={`Amount paid now (${fmt(paid)})`} value={paidStr} onChange={e => setPaidStr(e.target.value)} />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={updateCost} onChange={e => setUpdateCost(e.target.checked)} />Update product purchase price to these costs</label>
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2"><button className="btn-primary flex-1" onClick={() => void save()}>Save purchase &amp; add stock</button><button className="btn-ghost" onClick={onClose}>Cancel</button></div>
      </div>
      {addSup && <SupplierForm s={null} onClose={() => setAddSup(false)} onSaved={x => setSupplierId(x.id)} />}
    </Modal>
  )
}

function PurchaseDetail({ p, supplier, onClose }: { p: Purchase; supplier: string; onClose: () => void }) {
  const items = useLiveQuery(() => db.purchaseItems.where('purchase_id').equals(p.id).toArray(), [p.id]) ?? []
  return (
    <Modal title={`Purchase ${p.reference ?? ''}`.trim()} onClose={onClose}>
      <p className="text-sm text-slate-500 dark:text-slate-400">{supplier} · {new Date(p.created_at).toLocaleString('en-LK')}</p>
      <div className="my-3 divide-y divide-slate-300/50 text-sm dark:divide-white/10">
        {items.map(i => <div key={i.id} className="flex justify-between py-1.5"><span>{i.name} × {i.qty} @ {fmt(i.unit_cost)}</span><span>{fmt(i.line_total)}</span></div>)}
      </div>
      <div className="flex justify-between font-bold"><span>Total</span><span>{fmt(p.total)}</span></div>
      <div className="flex justify-between text-sm"><span>Paid</span><span>{fmt(p.paid)}</span></div>
      {p.total > p.paid && <div className="flex justify-between text-sm font-semibold text-amber-600"><span>Unpaid</span><span>{fmt(p.total - p.paid)}</span></div>}
    </Modal>
  )
}

function SupplierPayModal({ s, owed, onClose }: { s: Supplier; owed: number; onClose: () => void }) {
  const { profile } = useAuth()
  const [amt, setAmt] = useState(String(round2(owed)))
  const [method, setMethod] = useState('cash')
  const [note, setNote] = useState('')
  const [err, setErr] = useState('')
  return (
    <Modal title={`Pay ${s.name}`} onClose={onClose}>
      <div className="space-y-3">
        <p className="text-sm text-slate-500 dark:text-slate-400">Currently owed: {fmt(owed)}</p>
        <div className="flex gap-2">
          <input className="input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} />
          <select className="input !w-auto" value={method} onChange={e => setMethod(e.target.value)}><option value="cash">Cash</option><option value="bank_transfer">Bank</option><option value="card">Card</option></select>
        </div>
        <input className="input" placeholder="Note (optional)" value={note} onChange={e => setNote(e.target.value)} />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <div className="flex gap-2">
          <button className="btn-primary flex-1" onClick={async () => { if (!profile) return; const e = await paySupplier(s.id, Number(amt), method, note, profile.id); if (e) setErr(e); else onClose() }}>Record payment</button>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </Modal>
  )
}

export default function Purchases() {
  const purchases = useLiveQuery(() => db.purchases.orderBy('created_at').reverse().toArray(), []) ?? []
  const suppliers = useLiveQuery(() => db.suppliers.filter(s => !s.deleted_at).toArray(), []) ?? []
  const [tab, setTab] = useState<'purchases' | 'suppliers'>('purchases')
  const [newP, setNewP] = useState(false)
  const [sup, setSup] = useState<Supplier | 'new' | null>(null)
  const [detail, setDetail] = useState<Purchase | null>(null)
  const [payFor, setPayFor] = useState<Supplier | null>(null)
  const spay = useLiveQuery(() => db.supplierPayments.toArray(), []) ?? []
  const nameOf = (id: string | null) => suppliers.find(s => s.id === id)?.name ?? 'No supplier'
  const unpaid = (id: string) => round2(purchases.filter(p => p.supplier_id === id).reduce((t, p) => t + p.total - p.paid, 0) - spay.filter(p => p.supplier_id === id).reduce((t, p) => t + Number(p.amount), 0))

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button className={`${tab === 'purchases' ? 'btn-primary' : 'btn-ghost'} flex-1`} onClick={() => setTab('purchases')}>Purchases</button>
        <button className={`${tab === 'suppliers' ? 'btn-primary' : 'btn-ghost'} flex-1`} onClick={() => setTab('suppliers')}>Suppliers</button>
        {tab === 'purchases' ? <button className="btn-primary" onClick={() => setNewP(true)}><Plus size={16} />New</button> : <button className="btn-primary" onClick={() => setSup('new')}><Plus size={16} />Add</button>}
      </div>
      {tab === 'purchases' ? (
        purchases.length === 0 ? <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">No purchases yet. Record a supplier delivery to add stock.</div> :
        purchases.map(p => (
          <button key={p.id} className="glass flex w-full items-center justify-between gap-2 p-3 text-left" onClick={() => setDetail(p)}>
            <span className="min-w-0"><span className="block truncate font-semibold">{nameOf(p.supplier_id)}{p.reference ? ` · ${p.reference}` : ''}</span><span className="text-xs text-slate-500 dark:text-slate-400">{new Date(p.created_at).toLocaleString('en-LK')}</span></span>
            <span className="text-right"><span className="block font-semibold">{fmt(p.total)}</span>{p.total > p.paid && <span className="text-xs text-amber-600">unpaid {fmt(p.total - p.paid)}</span>}</span>
          </button>
        ))
      ) : suppliers.length === 0 ? <div className="glass p-8 text-center text-sm text-slate-500 dark:text-slate-400">No suppliers yet.</div> : suppliers.sort((a, b) => a.name.localeCompare(b.name)).map(s => (
        <div key={s.id} className="glass flex items-center gap-2 p-3">
          <div className="min-w-0 flex-1"><div className="truncate font-semibold">{s.name}</div><div className="truncate text-xs text-slate-500 dark:text-slate-400">{s.phone || 'No phone'}</div></div>
          {unpaid(s.id) > 0 && <div className="text-sm font-semibold text-amber-600">owed {fmt(unpaid(s.id))}</div>}
          {unpaid(s.id) > 0 && <button className="btn-ghost !px-3 !py-1.5" onClick={() => setPayFor(s)}>Pay</button>}
          <button className="rounded-lg p-2 hover:bg-slate-200/70 dark:hover:bg-white/10" onClick={() => setSup(s)} aria-label="Edit"><Pencil size={16} /></button>
        </div>
      ))}
      {newP && <PurchaseForm onClose={() => setNewP(false)} />}
      {sup && <SupplierForm s={sup === 'new' ? null : sup} onClose={() => setSup(null)} />}
      {payFor && <SupplierPayModal s={payFor} owed={unpaid(payFor.id)} onClose={() => setPayFor(null)} />}
      {detail && <PurchaseDetail p={detail} supplier={nameOf(detail.supplier_id)} onClose={() => setDetail(null)} />}
    </div>
  )
}
