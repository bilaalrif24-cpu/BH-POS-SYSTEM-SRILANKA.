import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Download, FileDown } from 'lucide-react'
import { db } from '../lib/db'
import { useBiz } from '../lib/hooks'
import { loadRange, summarize } from '../lib/stats'
import { addDays, presetRange, startOfDay, ymd, type Preset } from '../lib/dates'
import { downloadCsv, toCsv } from '../lib/csv'
import { tablePdf } from '../lib/pdf'
import { fmt, round2 } from '../lib/money'
import DataTable, { type Cell } from '../components/DataTable'

type Tab = 'sales' | 'pnl' | 'products' | 'returns' | 'inventory' | 'customers'
const TABS: [Tab, string][] = [['sales', 'Sales'], ['pnl', 'Profit & Loss'], ['products', 'Products'], ['returns', 'Returns'], ['inventory', 'Inventory'], ['customers', 'Credit']]
const PRESETS: [Preset, string][] = [['today', 'Today'], ['7d', '7 days'], ['month', 'This month'], ['lastmonth', 'Last month'], ['custom', 'Custom']]
const n2 = (n: number) => n.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export default function Reports() {
  const biz = useBiz()
  const [tab, setTab] = useState<Tab>('sales')
  const [preset, setPreset] = useState<Preset>('month')
  const [cFrom, setCFrom] = useState(ymd(addDays(new Date(), -29)))
  const [cTo, setCTo] = useState(ymd(new Date()))
  const [from, to] = preset === 'custom'
    ? [startOfDay(new Date(cFrom + 'T00:00:00')), addDays(startOfDay(new Date(cTo + 'T00:00:00')), 1)]
    : presetRange(preset)

  const data = useLiveQuery(() => loadRange(from, to), [from.getTime(), to.getTime()])
  const products = useLiveQuery(() => db.products.filter(p => !p.deleted_at).toArray(), []) ?? []
  const customers = useLiveQuery(() => db.customers.filter(c => !c.deleted_at).toArray(), []) ?? []
  if (!data) return <p className="p-6 text-center text-sm">Loading…</p>

  const sm = summarize(data)
  const cname = (id: string | null) => customers.find(c => c.id === id)?.name ?? 'Walk-in'
  const rangeLabel = `${ymd(from)} to ${ymd(addDays(to, -1))}`

  let title = '', head: string[] = [], rows: Cell[][] = [], summary: [string, number][] = []
  if (tab === 'sales') {
    title = 'Sales report'; head = ['Date', 'Invoice', 'Customer', 'Total', 'Paid', 'Balance']
    rows = [...data.sales].sort((a, b) => b.created_at.localeCompare(a.created_at)).map(s => [new Date(s.created_at).toLocaleString('en-LK'), s.invoice_no, cname(s.customer_id), s.total, s.paid, s.balance])
    rows = [...rows, ...data.returns.map(r => [new Date(r.created_at).toLocaleString('en-LK'), 'Return ' + r.invoice_no, cname(r.customer_id), -r.total, -r.refunded, -r.credit_reduced])]
    summary = [['Invoices', sm.count], ['Net sales (after returns)', sm.revenue], ['Refunds', sm.refunds], ['Collected (net)', sm.collected], ['On credit', sm.credit]]
  } else if (tab === 'pnl') {
    title = 'Profit and loss'; head = ['Item', 'Amount (LKR)']
    rows = [['Sales (before tax, after discounts)', sm.net], ['Cost of goods sold', -sm.cogs], ['Gross profit', sm.gross], ['Operating expenses', -sm.expenses], ['NET PROFIT', sm.profit], ['Tax collected (not income)', sm.tax]]
    summary = [['Net profit', sm.profit]]
  } else if (tab === 'products') {
    title = 'Product performance'; head = ['Product', 'Qty sold', 'Revenue', 'Cost', 'Profit']
    const m = new Map<string, { q: number; r: number; c: number }>()
    data.items.forEach(i => { const x = m.get(i.name) ?? { q: 0, r: 0, c: 0 }; m.set(i.name, { q: x.q + Number(i.qty), r: x.r + Number(i.line_total), c: x.c + Number(i.qty) * Number(i.unit_cost) }) })
    const rs = new Set(data.returns.filter(r => r.restocked).map(r => r.id))
    data.returnItems.forEach(i => { const x = m.get(i.name) ?? { q: 0, r: 0, c: 0 }; m.set(i.name, { q: x.q - Number(i.qty), r: x.r - Number(i.line_total), c: x.c - (rs.has(i.return_id) ? Number(i.qty) * Number(i.unit_cost) : 0) }) })
    rows = [...m.entries()].sort((a, b) => b[1].r - a[1].r).map(([n, x]) => [n, String(round2(x.q)), round2(x.r), round2(x.c), round2(x.r - x.c)])
  } else if (tab === 'inventory') {
    title = 'Inventory valuation (current stock)'; head = ['Product', 'Stock', 'Cost price', 'Value at cost', 'Value at retail']
    rows = [...products].sort((a, b) => a.name.localeCompare(b.name)).map(p => [p.name, String(p.stock_qty), Number(p.purchase_price), round2(Number(p.stock_qty) * Number(p.purchase_price)), round2(Number(p.stock_qty) * Number(p.selling_price))])
    summary = [['Value at cost', round2(products.reduce((s, p) => s + Number(p.stock_qty) * Number(p.purchase_price), 0))], ['Value at retail', round2(products.reduce((s, p) => s + Number(p.stock_qty) * Number(p.selling_price), 0))]]
  } else if (tab === 'returns') {
    title = 'Returns and voids'; head = ['Date', 'Invoice', 'Customer', 'Reason', 'Value', 'Refunded']
    rows = [...data.returns].sort((a, b) => b.created_at.localeCompare(a.created_at)).map(r => [new Date(r.created_at).toLocaleString('en-LK'), r.invoice_no, cname(r.customer_id), r.reason ?? '', r.total, r.refunded])
    summary = [['Returns', data.returns.length], ['Total value', sm.refunds]]
  } else {
    title = 'Customer credit (outstanding balances)'; head = ['Customer', 'Phone', 'Balance']
    const owing = customers.filter(c => Number(c.credit_balance) > 0).sort((a, b) => Number(b.credit_balance) - Number(a.credit_balance))
    rows = owing.map(c => [c.name, c.phone ?? '', Number(c.credit_balance)])
    summary = [['Total outstanding', round2(owing.reduce((s, c) => s + Number(c.credit_balance), 0))]]
  }
  const dated = tab === 'inventory' || tab === 'customers' ? 'as of today' : rangeLabel
  const asText = (r: Cell[]) => r.map(c => (typeof c === 'number' ? n2(c) : String(c)))
  const file = `${tab}-${ymd(new Date())}`

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">{TABS.map(([k, l]) => <button key={k} className={tab === k ? 'btn-primary' : 'btn-ghost'} onClick={() => setTab(k)}>{l}</button>)}</div>
      {tab !== 'inventory' && tab !== 'customers' && (
        <div className="flex flex-wrap items-center gap-2">
          {PRESETS.map(([k, l]) => <button key={k} className={`${preset === k ? 'btn-primary' : 'btn-ghost'} !px-3 !py-1.5`} onClick={() => setPreset(k)}>{l}</button>)}
          {preset === 'custom' && <><input className="input !w-auto" type="date" value={cFrom} onChange={e => e.target.value && setCFrom(e.target.value)} /><input className="input !w-auto" type="date" value={cTo} onChange={e => e.target.value && setCTo(e.target.value)} /></>}
        </div>
      )}
      <section className="glass space-y-3 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><h3 className="font-semibold">{title}</h3><p className="text-xs text-slate-500 dark:text-slate-400">{biz.name} · {dated}</p></div>
          <div className="flex gap-2">
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => downloadCsv(`${file}.csv`, toCsv([head, ...rows]))}><Download size={15} />CSV</button>
            <button className="btn-ghost !px-3 !py-1.5" onClick={() => void tablePdf(`${file}.pdf`, `${biz.name} — ${title}`, dated, head, rows.map(asText))}><FileDown size={15} />PDF</button>
          </div>
        </div>
        {summary.length > 0 && <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{summary.map(([l, v]) => (
          <div key={l} className="rounded-xl bg-slate-200/50 p-3 dark:bg-white/5"><div className="text-xs text-slate-500 dark:text-slate-400">{l}</div><div className="font-bold">{l === 'Invoices' || l === 'Returns' ? v : fmt(v)}</div></div>
        ))}</div>}
        <DataTable head={head} rows={rows} />
      </section>
    </div>
  )
}
