import { useEffect, useState } from 'react'
import { Monitor, Moon, Sun } from 'lucide-react'
import { useAuth } from '../lib/auth'
import { useSetting } from '../lib/hooks'
import { saveSetting } from '../lib/sync'
import { supabase } from '../lib/supabase'
import { useTheme, type ThemeMode } from '../lib/theme'
import type { Role } from '../lib/db'
import { fullResync } from '../lib/sync'
import Logo from '../components/Logo'
import BusinessSettings from './BusinessSettings'
import PrinterSettings from './PrinterSettings'
import SyncSettings from './SyncSettings'
import DataSettings from './DataSettings'

interface UserRow { id: string; email: string; full_name: string; role: Role; active: boolean }

function UsersPanel({ selfId }: { selfId: string }) {
  const [rows, setRows] = useState<UserRow[] | null>(null)
  const [err, setErr] = useState('')

  async function load() {
    if (!supabase) return
    if (!navigator.onLine) { setErr('Go online to manage users.'); return }
    const { data, error } = await supabase.from('profiles').select('id,email,full_name,role,active').order('created_at')
    if (error) setErr(error.message); else { setRows(data as UserRow[]); setErr('') }
  }
  useEffect(() => { void load() }, [])

  async function update(id: string, patch: Partial<UserRow>) {
    const { error } = await supabase!.from('profiles').update(patch).eq('id', id)
    if (error) setErr(error.message); else void load()
  }

  return (
    <section className="glass space-y-3 p-5">
      <h3 className="font-semibold">Users</h3>
      <p className="text-xs text-slate-500 dark:text-slate-400">New sign-ups appear here as inactive. Activate them and choose a role.</p>
      {err && <p className="text-sm text-red-500">{err}</p>}
      {rows === null && !err && <p className="text-sm">Loading…</p>}
      {rows?.map(u => (
        <div key={u.id} className="flex flex-wrap items-center gap-2 rounded-xl bg-slate-200/50 p-3 dark:bg-white/5">
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold">{u.full_name}</div>
            <div className="truncate text-xs text-slate-500 dark:text-slate-400">{u.email}</div>
          </div>
          <select className="input !w-auto !py-1.5" value={u.role} disabled={u.id === selfId} onChange={e => void update(u.id, { role: e.target.value as Role })}>
            <option value="admin">Admin</option><option value="manager">Manager</option><option value="cashier">Cashier</option>
          </select>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={u.active} disabled={u.id === selfId} onChange={e => void update(u.id, { active: e.target.checked })} />Active
          </label>
        </div>
      ))}
    </section>
  )
}

export default function Settings() {
  const { profile, signOut } = useAuth()
  const { mode, setMode } = useTheme()
  const business = useSetting('business_name', 'My Business')
  const [name, setName] = useState(business)
  const [saved, setSaved] = useState(false)
  const [sync, setSync] = useState('')
  useEffect(() => setName(business), [business])
  if (!profile) return null
  const canEdit = profile.role !== 'cashier'
  const themes: { id: ThemeMode; label: string; icon: typeof Sun }[] = [
    { id: 'system', label: 'System', icon: Monitor }, { id: 'light', label: 'Light', icon: Sun }, { id: 'dark', label: 'Dark', icon: Moon }
  ]

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <BusinessSettings canEdit={canEdit} />

      <section className="glass space-y-3 p-5">
        <h3 className="font-semibold">Appearance</h3>
        <div className="flex gap-2">
          {themes.map(t => (
            <button key={t.id} onClick={() => setMode(t.id)} className={`${mode === t.id ? 'btn-primary' : 'btn-ghost'} flex-1`}><t.icon size={16} />{t.label}</button>
          ))}
        </div>
      </section>

      <section className="glass space-y-2 p-5">
        <h3 className="font-semibold">Account</h3>
        <p className="text-sm">{profile.fullName} · {profile.email}</p>
        <p className="text-sm capitalize text-slate-500 dark:text-slate-400">Role: {profile.role}</p>
        <div className="flex flex-wrap gap-2"><button className="btn-ghost" onClick={() => void signOut()}>Sign out</button><button className="btn-ghost" onClick={async () => { setSync('Syncing…'); await fullResync(); setSync('Done — all data re-downloaded') }}>Re-download all data</button></div>
        {sync && <p className="text-sm text-emerald-500">{sync}</p>}
      </section>

      <PrinterSettings />
      <SyncSettings />
      {canEdit && <DataSettings isAdmin={profile.role === 'admin'} />}
      {profile.role === 'admin' && <UsersPanel selfId={profile.id} />}

      <section className="glass flex items-center gap-4 p-5">
        <Logo size={52} />
        <div>
          <div className="font-extrabold tracking-wide">BH POS STUDIO</div>
          <div className="text-xs font-semibold tracking-[0.25em] text-slate-500 dark:text-silver">BY BH GRAPHICS</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">MANAGE SMART. SELL BETTER. · v1.0.0 (Phase 1)</div>
        </div>
      </section>
    </div>
  )
}
