import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db } from '../lib/db'
import { syncNow } from '../lib/sync'
import { useOnline } from '../lib/hooks'

export default function SyncSettings() {
  const online = useOnline()
  const items = useLiveQuery(() => db.outbox.orderBy('createdAt').toArray(), []) ?? []
  const [busy, setBusy] = useState(false)
  const failing = items.filter(i => i.lastError)
  return (
    <section className="glass space-y-3 p-5">
      <h3 className="font-semibold">Sync status</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400">
        {online ? 'Online.' : 'Offline — changes are saved on this device and will upload when you reconnect.'}{' '}
        {items.length === 0 ? 'Everything is uploaded.' : `${items.length} change${items.length > 1 ? 's' : ''} waiting to upload.`}
      </p>
      {failing.length > 0 && (
        <div className="space-y-1 rounded-xl bg-red-500/10 p-3 text-xs">
          <div className="font-semibold text-red-600 dark:text-red-400">Some changes were rejected by the database:</div>
          {failing.slice(0, 5).map(i => <div key={i.id}><b>{i.table}</b> (tried {i.attempts}×): {i.lastError}</div>)}
          <div className="text-slate-500 dark:text-slate-400">A missing SQL file (phase3/4/5.sql) is the most common cause. Run it in Supabase, then press Sync now.</div>
        </div>
      )}
      <button className="btn-ghost" disabled={busy || !online} onClick={async () => { setBusy(true); await syncNow(); setBusy(false) }}>{busy ? 'Syncing…' : 'Sync now'}</button>
    </section>
  )
}
