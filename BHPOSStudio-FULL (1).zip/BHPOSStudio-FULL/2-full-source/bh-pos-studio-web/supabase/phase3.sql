-- Run this ONCE if you created your Supabase project with the Phase 1 or Phase 2 schema.
-- (New projects using the latest schema.sql already have it.)
alter table expenses add column if not exists deleted_at timestamptz;
