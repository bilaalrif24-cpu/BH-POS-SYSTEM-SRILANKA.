-- Run this ONCE if you created your Supabase project with an earlier schema (Phase 1-3). New projects: schema.sql already includes it.
create table sale_returns (
  id uuid primary key, sale_id uuid not null references sales, invoice_no text not null, customer_id uuid references customers,
  subtotal numeric(12,2) not null, discount numeric(12,2) not null default 0, tax numeric(12,2) not null default 0,
  total numeric(12,2) not null, refunded numeric(12,2) not null default 0, credit_reduced numeric(12,2) not null default 0,
  method text not null, reason text, restocked boolean not null default true,
  created_by uuid default auth.uid(), created_at timestamptz not null
);
create table sale_return_items (
  id uuid primary key, return_id uuid not null references sale_returns on delete cascade,
  sale_item_id uuid references sale_items, product_id uuid references products,
  name text not null, qty numeric(12,3) not null, unit_price numeric(12,2) not null, unit_cost numeric(12,2) not null default 0, line_total numeric(12,2) not null
);

-- A return that offsets credit lowers the customer's outstanding balance (stock comes back via 'return' stock movements).
create or replace function public.apply_return_credit() returns trigger language plpgsql security definer set search_path = public as
$$ begin if new.customer_id is not null and new.credit_reduced <> 0 then
     update customers set credit_balance = credit_balance - new.credit_reduced, updated_at = now() where id = new.customer_id; end if; return new; end $$;
create trigger trg_return_credit after insert on sale_returns for each row execute function public.apply_return_credit();

alter table sale_returns enable row level security;
alter table sale_return_items enable row level security;
create policy "read_sale_returns" on sale_returns for select to authenticated using (my_role() is not null);
create policy "read_sale_return_items" on sale_return_items for select to authenticated using (my_role() is not null);
create policy "mgr_ins_sale_returns" on sale_returns for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "mgr_ins_sale_return_items" on sale_return_items for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "admin_upd_sale_returns" on sale_returns for update to authenticated using (my_role() = 'admin');
create policy "admin_del_sale_returns" on sale_returns for delete to authenticated using (my_role() = 'admin');
