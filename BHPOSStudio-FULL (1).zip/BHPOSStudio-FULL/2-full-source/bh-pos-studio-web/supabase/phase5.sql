-- Run ONCE if your Supabase project was created before Phase 5. New projects: schema.sql already includes it.
create table supplier_payments (
  id uuid primary key, supplier_id uuid not null references suppliers, amount numeric(12,2) not null,
  method text not null, note text, created_by uuid default auth.uid(), created_at timestamptz not null
);
alter table supplier_payments enable row level security;
create policy "read_supplier_payments" on supplier_payments for select to authenticated using (my_role() is not null);
create policy "mgr_ins_supplier_payments" on supplier_payments for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "admin_upd_supplier_payments" on supplier_payments for update to authenticated using (my_role() = 'admin');
create policy "admin_del_supplier_payments" on supplier_payments for delete to authenticated using (my_role() = 'admin');
