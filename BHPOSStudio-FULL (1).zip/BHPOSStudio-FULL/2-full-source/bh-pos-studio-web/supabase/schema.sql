-- BH POS STUDIO — Supabase schema. Run once in Supabase > SQL Editor. Safe to re-run? No: run on a fresh project.
create extension if not exists pgcrypto;
create type app_role as enum ('admin', 'manager', 'cashier');

-- ---------- Users ----------
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  email text,
  full_name text,
  role app_role not null default 'cashier',
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create or replace function public.my_role() returns app_role
language sql stable security definer set search_path = public as
$$ select role from profiles where id = auth.uid() and active $$;

-- First account becomes an active admin. Later sign-ups are inactive cashiers until an admin approves them.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare first_user boolean;
begin
  select not exists (select 1 from profiles) into first_user;
  insert into profiles (id, email, full_name, role, active)
  values (new.id, new.email,
          coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
          case when first_user then 'admin'::app_role else 'cashier'::app_role end,
          first_user);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Business data ----------
create table settings (key text primary key, value text not null, updated_at timestamptz not null default now());
insert into settings (key, value) values ('business_name', 'My Business');

create table categories (id uuid primary key default gen_random_uuid(), name text not null unique, created_at timestamptz not null default now());

create table products (
  id uuid primary key default gen_random_uuid(),
  name text not null, sku text, barcode text unique,
  category_id uuid references categories on delete set null,
  purchase_price numeric(12,2) not null default 0,
  selling_price numeric(12,2) not null default 0,
  stock_qty numeric(12,3) not null default 0,
  low_stock_level numeric(12,3) not null default 5,
  image_url text, active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), deleted_at timestamptz
);
create table customers (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, email text, address text,
  credit_balance numeric(12,2) not null default 0,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), deleted_at timestamptz
);
create table suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, email text, address text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), deleted_at timestamptz
);

-- Sales/purchases/payments/movements are APPEND-ONLY and keyed by client-generated UUIDs,
-- so a retried offline upload can never create a duplicate row.
create table sales (
  id uuid primary key, invoice_no text not null unique,
  customer_id uuid references customers, cashier_id uuid default auth.uid(),
  subtotal numeric(12,2) not null, discount numeric(12,2) not null default 0, tax numeric(12,2) not null default 0,
  total numeric(12,2) not null, paid numeric(12,2) not null default 0, balance numeric(12,2) not null default 0,
  payment_method text not null check (payment_method in ('cash','card','bank_transfer','credit','mixed')),
  status text not null default 'completed', device_id text, created_at timestamptz not null
);
create table sale_items (
  id uuid primary key, sale_id uuid not null references sales on delete cascade, product_id uuid references products,
  name text not null, qty numeric(12,3) not null, unit_price numeric(12,2) not null, unit_cost numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0, line_total numeric(12,2) not null
);
create table payments (
  id uuid primary key, sale_id uuid references sales, customer_id uuid references customers,
  amount numeric(12,2) not null, method text not null, note text, created_at timestamptz not null
);
create table purchases (
  id uuid primary key, supplier_id uuid references suppliers, reference text,
  total numeric(12,2) not null, paid numeric(12,2) not null default 0, created_by uuid default auth.uid(), created_at timestamptz not null
);
create table purchase_items (
  id uuid primary key, purchase_id uuid not null references purchases on delete cascade, product_id uuid references products,
  name text not null, qty numeric(12,3) not null, unit_cost numeric(12,2) not null, line_total numeric(12,2) not null
);
create table expenses (
  id uuid primary key, category text not null, description text, amount numeric(12,2) not null,
  expense_date date not null, created_by uuid default auth.uid(), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), deleted_at timestamptz
);
create table stock_movements (
  id uuid primary key, product_id uuid not null references products,
  kind text not null check (kind in ('sale','purchase','adjustment','in','out','return')),
  qty numeric(12,3) not null,            -- signed: negative removes stock
  reason text, ref_id uuid, created_at timestamptz not null
);

-- Stock and customer credit are derived by triggers from append-only rows. Conflict-proof across devices.
create or replace function public.apply_stock_movement() returns trigger language plpgsql security definer set search_path = public as
$$ begin update products set stock_qty = stock_qty + new.qty, updated_at = now() where id = new.product_id; return new; end $$;
create trigger trg_stock after insert on stock_movements for each row execute function public.apply_stock_movement();

create or replace function public.apply_sale_credit() returns trigger language plpgsql security definer set search_path = public as
$$ begin if new.customer_id is not null and new.balance <> 0 then
     update customers set credit_balance = credit_balance + new.balance, updated_at = now() where id = new.customer_id; end if; return new; end $$;
create trigger trg_sale_credit after insert on sales for each row execute function public.apply_sale_credit();

create or replace function public.apply_payment() returns trigger language plpgsql security definer set search_path = public as
$$ begin if new.customer_id is not null and new.sale_id is null then
     update customers set credit_balance = credit_balance - new.amount, updated_at = now() where id = new.customer_id; end if; return new; end $$;
create trigger trg_payment after insert on payments for each row execute function public.apply_payment();

-- ---------- Row Level Security ----------
alter table profiles enable row level security;
create policy "profile_read" on profiles for select to authenticated using (id = auth.uid() or my_role() = 'admin');
create policy "profile_admin_update" on profiles for update to authenticated using (my_role() = 'admin') with check (my_role() = 'admin');

do $$ declare t text; begin
  foreach t in array array['settings','categories','products','suppliers','customers','sales','sale_items','payments','purchases','purchase_items','expenses','stock_movements'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "read_%1$s" on %1$I for select to authenticated using (my_role() is not null)', t);
  end loop;
  -- Admin/manager manage these
  foreach t in array array['settings','categories','products','suppliers','purchases','purchase_items','expenses'] loop
    execute format('create policy "mgr_all_%1$s" on %1$I for all to authenticated using (my_role() in (''admin'',''manager'')) with check (my_role() in (''admin'',''manager''))', t);
  end loop;
  -- Any active staff may insert these (cashiers sell); only admins edit/delete
  foreach t in array array['sales','sale_items','payments','stock_movements'] loop
    execute format('create policy "staff_ins_%1$s" on %1$I for insert to authenticated with check (my_role() is not null)', t);
    execute format('create policy "admin_upd_%1$s" on %1$I for update to authenticated using (my_role() = ''admin'')', t);
    execute format('create policy "admin_del_%1$s" on %1$I for delete to authenticated using (my_role() = ''admin'')', t);
  end loop;
end $$;
create policy "staff_ins_customers" on customers for insert to authenticated with check (my_role() is not null);
create policy "staff_upd_customers" on customers for update to authenticated using (my_role() is not null) with check (my_role() is not null);

-- ---------- Returns / voids (Phase 4) ----------
create table sale_returns (
  id uuid primary key, sale_id uuid not null references sales, invoice_no text not null, customer_id uuid references customers,
  subtotal numeric(12,2) not null, discount numeric(12,2) not null default 0, tax numeric(12,2) not null default 0,
  total numeric(12,2) not null, refunded numeric(12,2) not null default 0, credit_reduced numeric(12,2) not null default 0,
  method text not null, reason text, restocked boolean not null default true,
  created_by uuid default auth.uid(), created_at timestamptz not null
);
create table sale_return_items (
  id uuid primary key, return_id uuid not null references sale_returns on delete cascade,
  sale_item_id uuid references sale_items, product_id uuid references products,
  name text not null, qty numeric(12,3) not null, unit_price numeric(12,2) not null, unit_cost numeric(12,2) not null default 0, line_total numeric(12,2) not null
);

-- A return that offsets credit lowers the customer's outstanding balance (stock comes back via 'return' stock movements).
create or replace function public.apply_return_credit() returns trigger language plpgsql security definer set search_path = public as
$$ begin if new.customer_id is not null and new.credit_reduced <> 0 then
     update customers set credit_balance = credit_balance - new.credit_reduced, updated_at = now() where id = new.customer_id; end if; return new; end $$;
create trigger trg_return_credit after insert on sale_returns for each row execute function public.apply_return_credit();

alter table sale_returns enable row level security;
alter table sale_return_items enable row level security;
create policy "read_sale_returns" on sale_returns for select to authenticated using (my_role() is not null);
create policy "read_sale_return_items" on sale_return_items for select to authenticated using (my_role() is not null);
create policy "mgr_ins_sale_returns" on sale_returns for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "mgr_ins_sale_return_items" on sale_return_items for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "admin_upd_sale_returns" on sale_returns for update to authenticated using (my_role() = 'admin');
create policy "admin_del_sale_returns" on sale_returns for delete to authenticated using (my_role() = 'admin');

-- ---------- Supplier payments (Phase 5) ----------
create table supplier_payments (
  id uuid primary key, supplier_id uuid not null references suppliers, amount numeric(12,2) not null,
  method text not null, note text, created_by uuid default auth.uid(), created_at timestamptz not null
);
alter table supplier_payments enable row level security;
create policy "read_supplier_payments" on supplier_payments for select to authenticated using (my_role() is not null);
create policy "mgr_ins_supplier_payments" on supplier_payments for insert to authenticated with check (my_role() in ('admin','manager'));
create policy "admin_upd_supplier_payments" on supplier_payments for update to authenticated using (my_role() = 'admin');
create policy "admin_del_supplier_payments" on supplier_payments for delete to authenticated using (my_role() = 'admin');
