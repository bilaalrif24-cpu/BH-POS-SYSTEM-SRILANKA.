export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        royal: { DEFAULT: '#2F5BEA', dark: '#1B3FB8' },
        silver: '#C9D1DC',
        ink: '#05070D',
        navy: '#0B1226'
      },
      fontFamily: { sans: ['Inter', 'system-ui', 'Segoe UI', 'Roboto', 'sans-serif'] }
    }
  },
  plugins: []
}
