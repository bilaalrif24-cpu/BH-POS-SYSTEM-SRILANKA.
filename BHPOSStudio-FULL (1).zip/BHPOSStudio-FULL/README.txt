BH POS STUDIO — by BH GRAPHICS   (Manage Smart. Sell Better.)
=========================================================

This zip has TWO versions:

1-website/            READY-MADE WEBSITE (open index.html, or put it online in 1 minute)
2-full-source/        FULL PROJECT: React + TypeScript + Vite + Tailwind + Supabase + offline + PWA

---------------------------------------------------------
A) 1-website  (fastest — no coding, no database)
---------------------------------------------------------
Single-page POS: Dashboard, POS billing, Products, Inventory & purchases, Customers,
Expenses, Reports, Settings. Business name, logo and WhatsApp number are editable in Settings.
Data is saved in the browser of the device you use (no cloud). Download a backup regularly
(Settings -> Download backup).

Put it online (free, gives you a real website address):
  Netlify : go to app.netlify.com/drop  -> drag the "1-website" folder onto the page.
  Vercel  : vercel.com -> Add New -> Project -> upload the "1-website" folder.
Then open the address in Chrome. On Android: Chrome menu -> Install app.
(It needs internet the first time; after that it opens offline.)

---------------------------------------------------------
B) 2-full-source/bh-pos-studio-web  (multi-device, staff logins, cloud database)
---------------------------------------------------------
1. Create a free project at supabase.com. SQL Editor -> paste supabase/schema.sql -> Run.
2. Copy .env.example to .env and paste your Supabase URL and anon key.
3. In the folder run:   npm install   then   npm run dev
4. Deploy: push to GitHub -> Vercel/Netlify -> add the two environment variables -> Deploy.
Full instructions and the go-live checklist are in bh-pos-studio-web/README.md.
(If you need to build it again after changes: npm run build)
